import { NextRequest, NextResponse } from 'next/server'

export async function GET(request: NextRequest) {
  try {
    const searchParams = request.nextUrl.searchParams
    const astronautId = searchParams.get('astronautId')
    
    // Simulate astronaut data
    const astronauts = [
      {
        id: 'astro1',
        name: 'Sarah Chen',
        role: 'Mission Commander',
        status: 'nominal',
        vitals: {
          heartRate: 72 + Math.random() * 8,
          bloodOxygen: 98 - Math.random() * 2,
          temperature: 36.8 + (Math.random() - 0.5) * 0.4,
          respirationRate: 16 + Math.random() * 3,
          bloodPressure: { 
            systolic: 120 + Math.random() * 10, 
            diastolic: 80 + Math.random() * 8 
          },
          stressLevel: 25 + Math.random() * 10,
          hydration: 85 - Math.random() * 5
        },
        suit: {
          primaryOxygen: 85 - Math.random() * 5,
          secondaryOxygen: 95 - Math.random() * 3,
          batteryPower: 78 - Math.random() * 8,
          co2Scrubber: 70 - Math.random() * 10,
          internalPressure: 4.3 + (Math.random() - 0.5) * 0.2,
          externalPressure: 0.0,
          communicationSignal: 92 + (Math.random() - 0.5) * 5,
          coolingSystem: 65 + Math.random() * 10
        },
        eva: {
          status: 'active',
          duration: '2h 45m',
          startTime: '08:30 UTC',
          location: { 
            x: 1250 + Math.random() * 50, 
            y: 890 + Math.random() * 50, 
            z: 15 + Math.random() * 5 
          },
          currentTask: 'Solar Panel Installation',
          completedTasks: 3,
          totalTasks: 8,
          distanceTraveled: 1250 + Math.random() * 100,
          suitIntegrity: 98 - Math.random() * 2
        }
      },
      {
        id: 'astro2',
        name: 'Marcus Rodriguez',
        role: 'EVA Specialist',
        status: 'warning',
        vitals: {
          heartRate: 95 + Math.random() * 5,
          bloodOxygen: 96 - Math.random() * 2,
          temperature: 37.2 + (Math.random() - 0.5) * 0.3,
          respirationRate: 20 + Math.random() * 2,
          bloodPressure: { 
            systolic: 135 + Math.random() * 8, 
            diastolic: 88 + Math.random() * 6 
          },
          stressLevel: 65 + Math.random() * 10,
          hydration: 72 - Math.random() * 3
        },
        suit: {
          primaryOxygen: 65 - Math.random() * 8,
          secondaryOxygen: 90 - Math.random() * 5,
          batteryPower: 45 - Math.random() * 5,
          co2Scrubber: 55 - Math.random() * 8,
          internalPressure: 4.2 + (Math.random() - 0.5) * 0.2,
          externalPressure: 0.0,
          communicationSignal: 78 + (Math.random() - 0.5) * 8,
          coolingSystem: 80 + Math.random() * 5
        },
        eva: {
          status: 'active',
          duration: '3h 15m',
          startTime: '08:00 UTC',
          location: { 
            x: 980 + Math.random() * 30, 
            y: 1200 + Math.random() * 40, 
            z: 8 + Math.random() * 3 
          },
          currentTask: 'Sample Collection',
          completedTasks: 5,
          totalTasks: 7,
          distanceTraveled: 2100 + Math.random() * 150,
          suitIntegrity: 95 - Math.random() * 3
        }
      },
      {
        id: 'astro3',
        name: 'Dr. Elena Volkov',
        role: 'Science Officer',
        status: 'nominal',
        vitals: {
          heartRate: 68 + Math.random() * 6,
          bloodOxygen: 99 - Math.random() * 1,
          temperature: 36.6 + (Math.random() - 0.5) * 0.3,
          respirationRate: 14 + Math.random() * 2,
          bloodPressure: { 
            systolic: 118 + Math.random() * 8, 
            diastolic: 78 + Math.random() * 6 
          },
          stressLevel: 20 + Math.random() * 8,
          hydration: 90 - Math.random() * 3
        },
        suit: {
          primaryOxygen: 92 - Math.random() * 3,
          secondaryOxygen: 98 - Math.random() * 2,
          batteryPower: 88 - Math.random() * 4,
          co2Scrubber: 85 - Math.random() * 5,
          internalPressure: 4.4 + (Math.random() - 0.5) * 0.1,
          externalPressure: 0.0,
          communicationSignal: 95 + (Math.random() - 0.5) * 3,
          coolingSystem: 70 + Math.random() * 8
        },
        eva: {
          status: 'preparing',
          duration: '0h 0m',
          startTime: '12:00 UTC',
          location: { x: 0, y: 0, z: 0 },
          currentTask: 'Pre-EVA Checks',
          completedTasks: 0,
          totalTasks: 10,
          distanceTraveled: 0,
          suitIntegrity: 100
        }
      }
    ]

    const data = {
      timestamp: new Date().toISOString(),
      astronauts: astronautId ? astronauts.find(a => a.id === astronautId) : astronauts,
      networkStatus: {
        connected: true,
        latency: 45 + Math.random() * 20,
        packetLoss: Math.random() * 2
      }
    }

    return NextResponse.json(data)
  } catch (error) {
    console.error('Astronaut API error:', error)
    return NextResponse.json(
      { error: 'Failed to fetch astronaut data' },
      { status: 500 }
    )
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { action, astronautId, parameters } = body

    switch (action) {
      case 'update_vitals':
        return NextResponse.json({
          success: true,
          message: `Vitals updated for ${astronautId}`,
          timestamp: new Date().toISOString(),
          vitals: {
            heartRate: parameters.heartRate || 75,
            bloodOxygen: parameters.bloodOxygen || 98,
            temperature: parameters.temperature || 36.8
          }
        })
      
      case 'emergency_alert':
        return NextResponse.json({
          success: true,
          message: `Emergency alert triggered for ${astronautId}`,
          alertId: `alert_${Date.now()}`,
          severity: 'high',
          timestamp: new Date().toISOString()
        })
      
      case 'suit_calibration':
        return NextResponse.json({
          success: true,
          message: `Suit calibration completed for ${astronautId}`,
          calibrationResults: {
            pressure: 4.3,
            oxygenFlow: 2.1,
            batteryOptimization: 15
          }
        })
      
      case 'eva_update':
        return NextResponse.json({
          success: true,
          message: `EVA status updated for ${astronautId}`,
          evaStatus: parameters.status,
          location: parameters.location,
          timestamp: new Date().toISOString()
        })
      
      default:
        return NextResponse.json(
          { error: 'Unknown action' },
          { status: 400 }
        )
    }
  } catch (error) {
    console.error('Astronaut POST error:', error)
    return NextResponse.json(
      { error: 'Failed to process request' },
      { status: 500 }
    )
  }
}