import { NextRequest, NextResponse } from 'next/server'

export async function GET(request: NextRequest) {
  try {
    const searchParams = request.nextUrl.searchParams
    const nodeId = searchParams.get('nodeId')
    
    // Simulate bio-cochlea node data
    const nodes = [
      {
        id: 'alpha_node',
        name: 'Alpha Node',
        type: 'human',
        coherence: 85 + Math.random() * 15,
        power: 250 + Math.random() * 150,
        phase: Math.random() * 360,
        connected: true,
        layers: [
          {
            name: 'Biopolymer Encapsulation',
            activity: 80 + Math.random() * 20,
            thickness: 15,
            efficiency: 85 + Math.random() * 10
          },
          {
            name: 'Transduction Layer',
            activity: 85 + Math.random() * 15,
            thickness: 25,
            efficiency: 90 + Math.random() * 8
          },
          {
            name: 'Basilar Membrane',
            activity: 70 + Math.random() * 20,
            thickness: 35,
            efficiency: 75 + Math.random() * 15
          },
          {
            name: 'Mycelium-Bamboo Shell',
            activity: 80 + Math.random() * 15,
            thickness: 45,
            efficiency: 88 + Math.random() * 10
          }
        ]
      },
      {
        id: 'beta_node',
        name: 'Beta Node',
        type: 'human',
        coherence: 75 + Math.random() * 20,
        power: 200 + Math.random() * 120,
        phase: Math.random() * 360,
        connected: true,
        layers: [
          {
            name: 'Biopolymer Encapsulation',
            activity: 75 + Math.random() * 25,
            thickness: 15,
            efficiency: 80 + Math.random() * 15
          },
          {
            name: 'Transduction Layer',
            activity: 80 + Math.random() * 20,
            thickness: 25,
            efficiency: 85 + Math.random() * 12
          },
          {
            name: 'Basilar Membrane',
            activity: 65 + Math.random() * 25,
            thickness: 35,
            efficiency: 70 + Math.random() * 20
          },
          {
            name: 'Mycelium-Bamboo Shell',
            activity: 75 + Math.random() * 20,
            thickness: 45,
            efficiency: 82 + Math.random() * 13
          }
        ]
      }
    ]

    const powerFlow = [
      {
        source: 'Body Motion',
        destination: 'Piezo & Tribo',
        amount: 200 + Math.random() * 150,
        efficiency: 80 + Math.random() * 15
      },
      {
        source: 'Piezo & Tribo',
        destination: 'Rectifier',
        amount: 180 + Math.random() * 120,
        efficiency: 85 + Math.random() * 12
      },
      {
        source: 'Rectifier',
        destination: 'Microcontroller',
        amount: 160 + Math.random() * 100,
        efficiency: 90 + Math.random() * 8
      },
      {
        source: 'Microcontroller',
        destination: 'AUI Seed',
        amount: 140 + Math.random() * 80,
        efficiency: 85 + Math.random() * 12
      }
    ]

    const data = {
      timestamp: new Date().toISOString(),
      nodes: nodeId ? nodes.find(n => n.id === nodeId) : nodes,
      powerFlow,
      networkMetrics: {
        totalCoherence: 80 + Math.random() * 15,
        totalPower: (nodes.reduce((sum, n) => sum + n.power, 0) / 1000).toFixed(2),
        averageEfficiency: 85 + Math.random() * 10,
        activeConnections: Math.floor(Math.random() * 6) + 4
      }
    }

    return NextResponse.json(data)
  } catch (error) {
    console.error('Bio-Cochlea API error:', error)
    return NextResponse.json(
      { error: 'Failed to fetch bio-cochlea data' },
      { status: 500 }
    )
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { action, nodeId, parameters } = body

    switch (action) {
      case 'connect_node':
        return NextResponse.json({
          success: true,
          message: `Node ${nodeId} connected successfully`,
          nodeId,
          status: 'connected'
        })
      
      case 'disconnect_node':
        return NextResponse.json({
          success: true,
          message: `Node ${nodeId} disconnected`,
          nodeId,
          status: 'disconnected'
        })
      
      case 'adjust_coherence':
        return NextResponse.json({
          success: true,
          message: 'Coherence adjusted',
          nodeId,
          newCoherence: parameters.coherence
        })
      
      case 'calibrate_layers':
        return NextResponse.json({
          success: true,
          message: 'Layers calibrated',
          nodeId,
          calibrationResults: {
            efficiency: 88 + Math.random() * 10,
            resonance: 92 + Math.random() * 6
          }
        })
      
      default:
        return NextResponse.json(
          { error: 'Unknown action' },
          { status: 400 }
        )
    }
  } catch (error) {
    console.error('Bio-Cochlea POST error:', error)
    return NextResponse.json(
      { error: 'Failed to process request' },
      { status: 500 }
    )
  }
}