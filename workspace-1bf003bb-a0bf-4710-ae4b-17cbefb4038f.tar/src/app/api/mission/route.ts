import { NextRequest, NextResponse } from 'next/server'

// Config: Number of astronauts (e.g., for Artemis crew)
const NUM_ASTRONAUTS = 3

// Multi-astronaut simulator
class MultiAstronautSimulator {
  private astronauts: any[] = []
  private names = ['Cmdr. Reyes', 'Eng. Patel', 'Sci. Novak']
  private roles = ['Mission Commander', 'EVA Specialist', 'Science Officer']

  constructor(num: number) {
    for (let i = 0; i < num; i++) {
      const baseVitals = {
        heartRate: 70 + Math.random() * 20,
        hrv: 50 + Math.random() * 40,
        bloodOxygen: 96 + Math.random() * 4,
        temperature: 36.5 + Math.random() * 1,
        stressLevel: 20 + Math.random() * 30,
        status: 'nominal',
        evaActive: Math.random() > 0.3,
        location: { x: Math.random() * 1500, y: Math.random() * 1500, z: Math.random() * 20 },
        suitIntegrity: 95 + Math.random() * 5
      }
      this.astronauts.push(baseVitals)
    }
  }

  getCrewVitals() {
    return this.astronauts.map((vitals, i) => ({
      ...vitals,
      id: `astro-${i + 1}`,
      name: this.names[i % this.names.length],
      role: this.roles[i % this.roles.length],
      lastUpdate: new Date().toISOString()
    }))
  }

  getAggregateHRVInfluence() {
    const active = this.getCrewVitals().filter(a => a.evaActive)
    if (!active.length) return 1.0 // Neutral if no EVAs
    const avgHRV = active.reduce((sum, a) => sum + a.hrv, 0) / active.length
    const normalized = Math.min(1, Math.max(0, (avgHRV - 30) / 70))
    return 0.8 + normalized * 0.4
  }

  updateCrewVitals() {
    this.astronauts = this.astronauts.map(vitals => {
      const newHeartRate = Math.max(60, Math.min(100, vitals.heartRate + (Math.random() - 0.5) * 8))
      const newHRV = Math.max(20, Math.min(100, vitals.hrv + (Math.random() - 0.5) * 10))
      const newStress = Math.max(0, Math.min(100, vitals.stressLevel + (Math.random() - 0.5) * 8))
      
      let status = 'nominal'
      if (newHeartRate > 90 || newHRV < 30 || newStress > 70) {
        status = 'critical'
      } else if (newHeartRate > 80 || newHRV < 45 || newStress > 50) {
        status = 'elevated'
      }

      return {
        ...vitals,
        heartRate: newHeartRate,
        hrv: newHRV,
        stressLevel: newStress,
        status,
        location: vitals.evaActive ? {
          x: vitals.location.x + (Math.random() - 0.5) * 20,
          y: vitals.location.y + (Math.random() - 0.5) * 20,
          z: vitals.location.z + (Math.random() - 0.5) * 2
        } : vitals.location,
        suitIntegrity: vitals.evaActive ? Math.max(90, vitals.suitIntegrity - Math.random() * 0.1) : vitals.suitIntegrity
      }
    })
  }
}

// Network simulator with HRV influence
class NetworkSimulator {
  private coherence = 85
  private activeNodes = 6
  private totalPower = 2.5

  updateWithPhysioInfluence(hrvInfluence: number) {
    this.coherence = Math.min(100, Math.max(70, 85 + (hrvInfluence - 1) * 20))
    this.activeNodes = Math.floor(6 + (hrvInfluence - 1) * 4)
    this.totalPower = Math.max(1.5, Math.min(4.0, 2.5 + (hrvInfluence - 1) * 1.5))
  }

  getMetrics() {
    return {
      avgCoherence: this.coherence + (Math.random() - 0.5) * 5,
      activeNodes: this.activeNodes + Math.floor((Math.random() - 0.5) * 2),
      totalPower: this.totalPower + (Math.random() - 0.5) * 0.3
    }
  }
}

// Rover simulator with HRV influence
class RoverSimulator {
  private rovers = [
    { id: 'rover-1', name: 'LunRover-Alpha', battery: 78, signal: 92, efficiency: 87, task: 'Solar Panel Installation' },
    { id: 'rover-2', name: 'LunRover-Beta', battery: 65, signal: 78, efficiency: 72, task: 'Sample Collection' }
  ]

  updateWithHRVInfluence(hrvInfluence: number) {
    this.rovers = this.rovers.map(rover => ({
      ...rover,
      battery: Math.max(0, rover.battery - Math.random() * 0.3),
      signal: Math.max(70, Math.min(100, rover.signal + (Math.random() - 0.5) * 5)),
      efficiency: Math.min(100, Math.max(50, rover.efficiency + (hrvInfluence - 1) * 30)),
      status: rover.battery > 20 ? 'active' : 'standby'
    }))
  }

  getRovers() {
    return this.rovers.map(rover => ({
      ...rover,
      location: { 
        x: 1000 + Math.random() * 500, 
        y: 800 + Math.random() * 500 
      }
    }))
  }
}

// Singletons
const multiAstroSim = new MultiAstronautSimulator(NUM_ASTRONAUTS)
const networkSim = new NetworkSimulator()
const roverSim = new RoverSimulator()

export async function GET(request: NextRequest) {
  try {
    const searchParams = request.nextUrl.searchParams
    const endpoint = searchParams.get('endpoint') || 'overview'

    // Update all simulators
    multiAstroSim.updateCrewVitals()
    const hrvInfluence = multiAstroSim.getAggregateHRVInfluence()
    networkSim.updateWithPhysioInfluence(hrvInfluence)
    roverSim.updateWithHRVInfluence(hrvInfluence)

    switch (endpoint) {
      case 'crew':
        const crew = multiAstroSim.getCrewVitals()
        const aggregateHRV = crew.filter(c => c.evaActive).reduce((sum, c) => sum + c.hrv, 0) / crew.filter(c => c.evaActive).length || 65
        
        return NextResponse.json({
          crew,
          aggregateHRV,
          hrvInfluence,
          timestamp: new Date().toISOString()
        })

      case 'network':
        const networkMetrics = networkSim.getMetrics()
        return NextResponse.json({
          ...networkMetrics,
          hrvInfluence,
          timestamp: new Date().toISOString()
        })

      case 'rovers':
        const rovers = roverSim.getRovers()
        return NextResponse.json({
          rovers,
          hrvInfluence,
          timestamp: new Date().toISOString()
        })

      case 'overview':
      default:
        const crewData = multiAstroSim.getCrewVitals()
        const networkData = networkSim.getMetrics()
        const roverData = roverSim.getRovers()
        const avgHRV = crewData.reduce((sum, c) => sum + c.hrv, 0) / crewData.length
        
        // Generate alerts
        const alerts = []
        crewData.forEach(member => {
          if (member.status === 'critical') {
            alerts.push({
              id: `alert-${Date.now()}-${member.id}`,
              type: 'critical',
              source: 'crew',
              message: `Critical vitals for ${member.name} - HR: ${member.heartRate}, HRV: ${member.hrv}`,
              timestamp: new Date().toISOString(),
              acknowledged: false
            })
          } else if (member.status === 'elevated' && Math.random() > 0.7) {
            alerts.push({
              id: `alert-${Date.now()}-${member.id}`,
              type: 'warning',
              source: 'crew',
              message: `Elevated stress levels for ${member.name}`,
              timestamp: new Date().toISOString(),
              acknowledged: false
            })
          }
        })

        if (avgHRV < 40) {
          alerts.push({
            id: `alert-${Date.now()}-network`,
            type: 'warning',
            source: 'network',
            message: `Low aggregate HRV (${avgHRV.toFixed(0)}ms) affecting network coherence`,
            timestamp: new Date().toISOString(),
            acknowledged: false
          })
        }

        return NextResponse.json({
          crew: crewData,
          network: {
            ...networkData,
            aggregateHRV: avgHRV,
            impactFactor: hrvInfluence
          },
          rovers: roverData,
          alerts: alerts.slice(0, 20), // Keep last 20 alerts
          timestamp: new Date().toISOString()
        })
    }
  } catch (error) {
    console.error('Mission API error:', error)
    return NextResponse.json(
      { error: 'Failed to fetch mission data' },
      { status: 500 }
    )
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { action, astronautId, parameters } = body

    switch (action) {
      case 'acknowledge_alert':
        return NextResponse.json({
          success: true,
          message: `Alert acknowledged`,
          alertId: parameters.alertId
        })
      
      case 'adjust_crew_parameters':
        return NextResponse.json({
          success: true,
          message: `Crew parameters adjusted`,
          adjustments: parameters
        })
      
      case 'optimize_network':
        return NextResponse.json({
          success: true,
          message: 'Network optimization completed',
          results: {
            improvedCoherence: 5 + Math.random() * 10,
            reducedLatency: Math.random() * 2,
            hrvOptimization: Math.random() * 15
          }
        })
      
      case 'emergency_protocol':
        return NextResponse.json({
          success: true,
          message: `Emergency protocol activated`,
          protocolId: `emergency_${Date.now()}`,
          affectedSystems: ['crew', 'network', 'rovers']
        })
      
      default:
        return NextResponse.json(
          { error: 'Unknown action' },
          { status: 400 }
        )
    }
  } catch (error) {
    console.error('Mission POST error:', error)
    return NextResponse.json(
      { error: 'Failed to process request' },
      { status: 500 }
    )
  }
}