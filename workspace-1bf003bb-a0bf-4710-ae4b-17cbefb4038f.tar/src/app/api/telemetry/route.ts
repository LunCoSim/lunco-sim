import { NextRequest, NextResponse } from 'next/server'

export async function GET(request: NextRequest) {
  try {
    const searchParams = request.nextUrl.searchParams
    const scenario = searchParams.get('scenario') || 'apollo17_harrison'
    
    // Simulate different telemetry data based on scenario
    const scenarioData = {
      apollo17_harrison: {
        rover: {
          name: 'LunRover-1',
          battery: 75 + Math.random() * 20,
          temperature: -20 + Math.random() * 40,
          signal: 60 + Math.random() * 35,
          position: {
            x: Math.random() * 1000,
            y: Math.random() * 1000,
            z: Math.random() * 10
          }
        },
        environment: {
          temperature: -180 + Math.random() * 120,
          radiation: 0.1 + Math.random() * 0.4,
          gravity: 1.62,
          lighting: Math.random() * 100,
          dust: Math.random() * 50
        }
      },
      artemis3_landing: {
        rover: {
          name: 'Artemis-Rover',
          battery: 80 + Math.random() * 15,
          temperature: -200 + Math.random() * 80,
          signal: 70 + Math.random() * 25,
          position: {
            x: Math.random() * 500,
            y: Math.random() * 500,
            z: Math.random() * 5
          }
        },
        environment: {
          temperature: -220 + Math.random() * 100,
          radiation: 0.2 + Math.random() * 0.3,
          gravity: 1.62,
          lighting: Math.random() * 80,
          dust: Math.random() * 70
        }
      },
      swarm_12_micros: {
        rover: {
          name: 'Micro-Rover-Alpha',
          battery: 60 + Math.random() * 30,
          temperature: -150 + Math.random() * 100,
          signal: 50 + Math.random() * 40,
          position: {
            x: Math.random() * 2000,
            y: Math.random() * 2000,
            z: Math.random() * 20
          }
        },
        environment: {
          temperature: -160 + Math.random() * 110,
          radiation: 0.15 + Math.random() * 0.35,
          gravity: 1.62,
          lighting: Math.random() * 90,
          dust: Math.random() * 60
        }
      },
      night_survival: {
        rover: {
          name: 'Survival-Rover',
          battery: 30 + Math.random() * 40,
          temperature: -240 + Math.random() * 40,
          signal: 30 + Math.random() * 30,
          position: {
            x: Math.random() * 100,
            y: Math.random() * 100,
            z: Math.random() * 2
          }
        },
        environment: {
          temperature: -250 + Math.random() * 20,
          radiation: 0.05 + Math.random() * 0.15,
          gravity: 1.62,
          lighting: Math.random() * 10,
          dust: Math.random() * 30
        }
      }
    }

    const data = scenarioData[scenario as keyof typeof scenarioData] || scenarioData.apollo17_harrison

    const telemetry = {
      timestamp: new Date().toISOString(),
      scenario,
      ...data,
      mission: {
        elapsed: `${Math.floor(Math.random() * 8)}h ${Math.floor(Math.random() * 60)}m`,
        progress: Math.random() * 100,
        objectives: Math.floor(Math.random() * 10) + 5,
        completed: Math.floor(Math.random() * 8)
      }
    }

    return NextResponse.json(telemetry)
  } catch (error) {
    console.error('Telemetry API error:', error)
    return NextResponse.json(
      { error: 'Failed to fetch telemetry data' },
      { status: 500 }
    )
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { action, scenario, parameters } = body

    // Handle different actions
    switch (action) {
      case 'start_simulation':
        return NextResponse.json({
          success: true,
          message: `Simulation started for ${scenario}`,
          simulationId: `sim_${Date.now()}`
        })
      
      case 'stop_simulation':
        return NextResponse.json({
          success: true,
          message: 'Simulation stopped'
        })
      
      case 'update_parameters':
        return NextResponse.json({
          success: true,
          message: 'Parameters updated',
          parameters
        })
      
      default:
        return NextResponse.json(
          { error: 'Unknown action' },
          { status: 400 }
        )
    }
  } catch (error) {
    console.error('Telemetry POST error:', error)
    return NextResponse.json(
      { error: 'Failed to process request' },
      { status: 500 }
    )
  }
}