'use client'

import { useState } from 'react'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Separator } from '@/components/ui/separator'
import { 
  Rocket, 
  Activity, 
  Network, 
  Moon, 
  Ear, 
  Heart, 
  Zap, 
  Radio,
  Users,
  Globe,
  Cpu,
  Battery,
  Wifi,
  User,
  Command
} from 'lucide-react'
import LunCoSimDashboard from '@/components/LunCoSimDashboard'
import BioCochleaVisualization from '@/components/BioCochleaVisualization'
import NetworkResonanceView from '@/components/NetworkResonanceView'
import AstronautMonitor from '@/components/AstronautMonitor'
import MissionCommandCenter from '@/components/MissionCommandCenter'

export default function Home() {
  const [activeView, setActiveView] = useState('overview')

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 text-white">
      <div className="container mx-auto p-6">
        {/* Header */}
        <header className="mb-8">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="relative w-12 h-12">
                <img
                  src="/logo.png"
                  alt="LunCoSim × Bio-Cochlea Logo"
                  className="w-full h-full object-contain"
                />
              </div>
              <div className="flex items-center gap-2">
                <Moon className="h-8 w-8 text-purple-400" />
                <Rocket className="h-6 w-6 text-blue-400" />
              </div>
              <div>
                <h1 className="text-3xl font-bold bg-gradient-to-r from-purple-400 to-blue-400 bg-clip-text text-transparent">
                  LunCoSim × Bio-Cochlea Interface
                </h1>
                <p className="text-gray-400 text-sm">
                  Lunar Mission Control meets Bio-Resonance Technology
                </p>
              </div>
            </div>
            <div className="flex items-center gap-4">
              <Badge variant="outline" className="text-green-400 border-green-400">
                <Activity className="h-3 w-3 mr-1" />
                Systems Online
              </Badge>
              <Badge variant="outline" className="text-blue-400 border-blue-400">
                <Wifi className="h-3 w-3 mr-1" />
                Network Connected
              </Badge>
            </div>
          </div>
        </header>

        {/* Main Content */}
        <Tabs value={activeView} onValueChange={setActiveView} className="space-y-6">
          <TabsList className="grid w-full grid-cols-6 bg-slate-800/50 border border-slate-700">
            <TabsTrigger value="overview" className="data-[state=active]:bg-purple-600">
              <Globe className="h-4 w-4 mr-2" />
              Overview
            </TabsTrigger>
            <TabsTrigger value="luncosim" className="data-[state=active]:bg-blue-600">
              <Moon className="h-4 w-4 mr-2" />
              LunCoSim
            </TabsTrigger>
            <TabsTrigger value="biocochlea" className="data-[state=active]:bg-green-600">
              <Ear className="h-4 w-4 mr-2" />
              Bio-Cochlea
            </TabsTrigger>
            <TabsTrigger value="network" className="data-[state=active]:bg-orange-600">
              <Network className="h-4 w-4 mr-2" />
              Resonance
            </TabsTrigger>
            <TabsTrigger value="astronaut" className="data-[state=active]:bg-red-600">
              <User className="h-4 w-4 mr-2" />
              Astronaut
            </TabsTrigger>
            <TabsTrigger value="command" className="data-[state=active]:bg-indigo-600">
              <Command className="h-4 w-4 mr-2" />
              Command
            </TabsTrigger>
          </TabsList>

          {/* Overview Tab */}
          <TabsContent value="overview" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-6 gap-4">
              <Card className="bg-slate-800/50 border-slate-700">
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium text-gray-400">Lunar Simulations</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center gap-2">
                    <Rocket className="h-8 w-8 text-blue-400" />
                    <div>
                      <div className="text-2xl font-bold">12</div>
                      <div className="text-xs text-green-400">Active Scenarios</div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-slate-800/50 border-slate-700">
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium text-gray-400">Bio-Nodes</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center gap-2">
                    <Ear className="h-8 w-8 text-green-400" />
                    <div>
                      <div className="text-2xl font-bold">8</div>
                      <div className="text-xs text-green-400">Connected</div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-slate-800/50 border-slate-700">
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium text-gray-400">Astronauts</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center gap-2">
                    <User className="h-8 w-8 text-red-400" />
                    <div>
                      <div className="text-2xl font-bold">3</div>
                      <div className="text-xs text-green-400">On Mission</div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-slate-800/50 border-slate-700">
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium text-gray-400">Network Coherence</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center gap-2">
                    <Heart className="h-8 w-8 text-red-400 animate-pulse" />
                    <div>
                      <div className="text-2xl font-bold">94%</div>
                      <div className="text-xs text-green-400">Synchronized</div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-slate-800/50 border-slate-700">
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium text-gray-400">Aggregate HRV</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center gap-2">
                    <Activity className="h-8 w-8 text-purple-400 animate-pulse" />
                    <div>
                      <div className="text-2xl font-bold">62</div>
                      <div className="text-xs text-green-400">ms</div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-slate-800/50 border-slate-700">
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium text-gray-400">Power Harvest</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center gap-2">
                    <Battery className="h-8 w-8 text-yellow-400" />
                    <div>
                      <div className="text-2xl font-bold">2.4mW</div>
                      <div className="text-xs text-green-400">Total Output</div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              <Card className="bg-slate-800/50 border-slate-700">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Moon className="h-5 w-5 text-blue-400" />
                    Active Lunar Scenarios
                  </CardTitle>
                  <CardDescription>
                    Currently running LunCoSim mission simulations
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-3">
                  {[
                    { name: 'Apollo17 Harrison', status: 'active', progress: 78 },
                    { name: 'Artemis3 Landing', status: 'active', progress: 45 },
                    { name: 'Swarm 12 Micros', status: 'standby', progress: 12 },
                    { name: 'Night Survival', status: 'active', progress: 89 }
                  ].map((scenario, index) => (
                    <div key={index} className="flex items-center justify-between p-3 bg-slate-700/50 rounded-lg">
                      <div className="flex items-center gap-3">
                        <div className={`w-2 h-2 rounded-full ${
                          scenario.status === 'active' ? 'bg-green-400 animate-pulse' : 'bg-yellow-400'
                        }`} />
                        <span className="text-sm">{scenario.name}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <div className="w-20 bg-slate-600 rounded-full h-2">
                          <div 
                            className="bg-blue-400 h-2 rounded-full transition-all duration-300"
                            style={{ width: `${scenario.progress}%` }}
                          />
                        </div>
                        <span className="text-xs text-gray-400">{scenario.progress}%</span>
                      </div>
                    </div>
                  ))}
                </CardContent>
              </Card>

              <Card className="bg-slate-800/50 border-slate-700">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Users className="h-5 w-5 text-green-400" />
                    Bio-Cochlea Network
                  </CardTitle>
                  <CardDescription>
                    Human-AUI resonance connections and coherence metrics
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-3">
                  {[
                    { user: 'Alpha Node', coherence: 98, power: '320µW', status: 'coherent' },
                    { user: 'Beta Node', coherence: 87, power: '280µW', status: 'coherent' },
                    { user: 'Gamma Node', coherence: 92, power: '410µW', status: 'coherent' },
                    { user: 'Delta Node', coherence: 45, power: '120µW', status: 'syncing' }
                  ].map((node, index) => (
                    <div key={index} className="flex items-center justify-between p-3 bg-slate-700/50 rounded-lg">
                      <div className="flex items-center gap-3">
                        <Heart className={`h-4 w-4 ${
                          node.status === 'coherent' ? 'text-green-400 animate-pulse' : 'text-yellow-400'
                        }`} />
                        <span className="text-sm">{node.user}</span>
                      </div>
                      <div className="flex items-center gap-4">
                        <div className="text-right">
                          <div className="text-xs text-gray-400">Coherence</div>
                          <div className="text-sm font-medium">{node.coherence}%</div>
                        </div>
                        <div className="text-right">
                          <div className="text-xs text-gray-400">Power</div>
                          <div className="text-sm font-medium">{node.power}</div>
                        </div>
                      </div>
                    </div>
                  ))}
                </CardContent>
              </Card>

              <Card className="bg-slate-800/50 border-slate-700">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <User className="h-5 w-5 text-red-400" />
                    Astronaut Status
                  </CardTitle>
                  <CardDescription>
                    Real-time astronaut vital signs and EVA status
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-3">
                  {[
                    { name: 'Sarah Chen', role: 'Commander', status: 'nominal', eva: 'Active' },
                    { name: 'Marcus Rodriguez', role: 'EVA Specialist', status: 'warning', eva: 'Active' },
                    { name: 'Dr. Elena Volkov', role: 'Science Officer', status: 'nominal', eva: 'Preparing' }
                  ].map((astronaut, index) => (
                    <div key={index} className="flex items-center justify-between p-3 bg-slate-700/50 rounded-lg">
                      <div className="flex items-center gap-3">
                        <div className={`w-2 h-2 rounded-full ${
                          astronaut.status === 'nominal' ? 'bg-green-400 animate-pulse' : 
                          astronaut.status === 'warning' ? 'bg-yellow-400 animate-pulse' : 'bg-red-400 animate-pulse'
                        }`} />
                        <div>
                          <div className="text-sm font-medium">{astronaut.name}</div>
                          <div className="text-xs text-gray-400">{astronaut.role}</div>
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        <Badge variant={astronaut.eva === 'Active' ? 'default' : 'secondary'} className="text-xs">
                          {astronaut.eva}
                        </Badge>
                        <Badge 
                          variant="outline" 
                          className={`text-xs ${
                            astronaut.status === 'nominal' ? 'text-green-400 border-green-400' :
                            astronaut.status === 'warning' ? 'text-yellow-400 border-yellow-400' :
                            'text-red-400 border-red-400'
                          }`}
                        >
                          {astronaut.status}
                        </Badge>
                      </div>
                    </div>
                  ))}
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* LunCoSim Tab */}
          <TabsContent value="luncosim">
            <LunCoSimDashboard />
          </TabsContent>

          {/* Bio-Cochlea Tab */}
          <TabsContent value="biocochlea">
            <BioCochleaVisualization />
          </TabsContent>

          {/* Network Resonance Tab */}
          <TabsContent value="network">
            <NetworkResonanceView />
          </TabsContent>

          {/* Astronaut Monitor Tab */}
          <TabsContent value="astronaut">
            <AstronautMonitor />
          </TabsContent>

          {/* Mission Command Center Tab */}
          <TabsContent value="command">
            <MissionCommandCenter />
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}