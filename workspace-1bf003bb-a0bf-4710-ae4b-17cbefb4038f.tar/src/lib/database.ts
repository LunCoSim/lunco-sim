import { PrismaClient } from '@prisma/client'

const globalForPrisma = globalThis as unknown as {
  prisma: PrismaClient | undefined
}

export const prisma = globalForPrisma.prisma ?? new PrismaClient({
  log: ['query'],
})

if (process.env.NODE_ENV !== 'production') globalForPrisma.prisma = prisma

// Database service functions
export class DatabaseService {
  // Astronaut operations
  static async getAstronauts() {
    return await prisma.astronaut.findMany({
      include: {
        vitalSigns: {
          orderBy: { timestamp: 'desc' },
          take: 1
        },
        evaSessions: {
          where: { status: 'active' },
          orderBy: { startTime: 'desc' },
          take: 1
        },
        suitTelemetry: {
          orderBy: { timestamp: 'desc' },
          take: 1
        }
      }
    })
  }

  static async createAstronaut(data: {
    name: string
    role: string
    status?: string
  }) {
    return await prisma.astronaut.create({
      data
    })
  }

  static async updateAstronaut(id: string, data: {
    name?: string
    role?: string
    status?: string
  }) {
    return await prisma.astronaut.update({
      where: { id },
      data
    })
  }

  // Vital signs operations
  static async createVitalSign(data: {
    astronautId: string
    heartRate: number
    hrv: number
    bloodOxygen: number
    temperature: number
    respirationRate: number
    bloodPressureSys: number
    bloodPressureDia: number
    stressLevel: number
    hydration: number
  }) {
    return await prisma.vitalSign.create({
      data
    })
  }

  static async getLatestVitalSigns(astronautId: string) {
    return await prisma.vitalSign.findMany({
      where: { astronautId },
      orderBy: { timestamp: 'desc' },
      take: 10
    })
  }

  static async getVitalSignsHistory(astronautId: string, hours: number = 24) {
    const since = new Date(Date.now() - hours * 60 * 60 * 1000)
    return await prisma.vitalSign.findMany({
      where: {
        astronautId,
        timestamp: { gte: since }
      },
      orderBy: { timestamp: 'asc' }
    })
  }

  // EVA session operations
  static async createEVASession(data: {
    astronautId: string
    startTime: Date
    locationX: number
    locationY: number
    locationZ: number
    currentTask: string
    totalTasks: number
  }) {
    return await prisma.eVASession.create({
      data
    })
  }

  static async updateEVASession(id: string, data: {
    status?: string
    endTime?: Date
    duration?: number
    locationX?: number
    locationY?: number
    locationZ?: number
    currentTask?: string
    completedTasks?: number
    distanceTraveled?: number
    suitIntegrity?: number
  }) {
    return await prisma.eVASession.update({
      where: { id },
      data
    })
  }

  static async getActiveEVASessions() {
    return await prisma.eVASession.findMany({
      where: { status: 'active' },
      include: {
        astronaut: true
      }
    })
  }

  // Suit telemetry operations
  static async createSuitTelemetry(data: {
    astronautId: string
    primaryOxygen: number
    secondaryOxygen: number
    batteryPower: number
    co2Scrubber: number
    internalPressure: number
    externalPressure: number
    communicationSignal: number
    coolingSystem: number
  }) {
    return await prisma.suitTelemetry.create({
      data
    })
  }

  static async getLatestSuitTelemetry(astronautId: string) {
    return await prisma.suitTelemetry.findMany({
      where: { astronautId },
      orderBy: { timestamp: 'desc' },
      take: 1
    })
  }

  // Bio-network operations
  static async getBioNodes() {
    return await prisma.bioNode.findMany({
      include: {
        connections: true,
        targetConnections: true
      }
    })
  }

  static async upsertBioNode(data: {
    nodeId: string
    name: string
    type: string
    coherence: number
    power: number
    phase: number
    connected: boolean
  }) {
    return await prisma.bioNode.upsert({
      where: { nodeId: data.nodeId },
      update: data,
      create: data
    })
  }

  static async createConnection(data: {
    sourceId: string
    targetId: string
    strength: number
    active: boolean
    phase: number
  }) {
    return await prisma.connection.create({
      data
    })
  }

  static async updateConnection(id: string, data: {
    strength?: number
    active?: boolean
    phase?: number
  }) {
    return await prisma.connection.update({
      where: { id },
      data
    })
  }

  // Network metrics operations
  static async createNetworkMetric(data: {
    avgCoherence: number
    aggregateHRV: number
    impactFactor: number
    correlation: number
    activeNodes: number
    totalPower: number
  }) {
    return await prisma.networkMetric.create({
      data
    })
  }

  static async getNetworkMetrics(hours: number = 24) {
    const since = new Date(Date.now() - hours * 60 * 60 * 1000)
    return await prisma.networkMetric.findMany({
      where: {
        timestamp: { gte: since }
      },
      orderBy: { timestamp: 'asc' }
    })
  }

  // Rover operations
  static async getRovers() {
    return await prisma.rover.findMany()
  }

  static async upsertRover(data: {
    roverId: string
    name: string
    battery: number
    signal: number
    status: string
    task: string
    locationX: number
    locationY: number
    efficiency: number
  }) {
    return await prisma.rover.upsert({
      where: { roverId: data.roverId },
      update: data,
      create: data
    })
  }

  // Mission operations
  static async getMissions() {
    return await prisma.mission.findMany()
  }

  static async upsertMission(data: {
    scenarioId: string
    name: string
    description: string
    location: string
    duration: string
    difficulty: string
    status: string
    progress: number
  }) {
    return await prisma.mission.upsert({
      where: { scenarioId: data.scenarioId },
      update: data,
      create: data
    })
  }

  // Alert operations
  static async createAlert(data: {
    type: string
    source: string
    message: string
  }) {
    return await prisma.alert.create({
      data
    })
  }

  static async getAlerts(limit: number = 50) {
    return await prisma.alert.findMany({
      orderBy: { timestamp: 'desc' },
      take: limit
    })
  }

  static async acknowledgeAlert(id: string, acknowledgedBy: string) {
    return await prisma.alert.update({
      where: { id },
      data: {
        acknowledged: true,
        acknowledgedAt: new Date(),
        acknowledgedBy
      }
    })
  }

  // Cleanup operations
  static async cleanupOldData(days: number = 30) {
    const cutoffDate = new Date(Date.now() - days * 24 * 60 * 60 * 1000)
    
    await prisma.vitalSign.deleteMany({
      where: { timestamp: { lt: cutoffDate } }
    })
    
    await prisma.suitTelemetry.deleteMany({
      where: { timestamp: { lt: cutoffDate } }
    })
    
    await prisma.networkMetric.deleteMany({
      where: { timestamp: { lt: cutoffDate } }
    })
    
    await prisma.alert.deleteMany({
      where: { 
        timestamp: { lt: cutoffDate },
        acknowledged: true
      }
    })
  }
}