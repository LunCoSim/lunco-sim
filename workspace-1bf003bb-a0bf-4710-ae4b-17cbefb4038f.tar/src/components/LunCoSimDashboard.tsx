'use client'

import { useState, useEffect } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Progress } from '@/components/ui/progress'
import { Separator } from '@/components/ui/separator'
import { ScrollArea } from '@/components/ui/scroll-area'
import { 
  Moon, 
  Rocket, 
  Activity, 
  Thermometer,
  Wind,
  Battery,
  Radio,
  MapPin,
  Clock,
  AlertTriangle,
  CheckCircle,
  Satellite,
  Gauge,
  Compass,
  Sun,
  Zap
} from 'lucide-react'

interface TelemetryData {
  timestamp: string
  rover: {
    name: string
    position: { x: number; y: number; z: number }
    battery: number
    temperature: number
    signal: number
    status: 'active' | 'standby' | 'error'
  }
  environment: {
    temperature: number
    radiation: number
    gravity: number
    lighting: number
    dust: number
  }
  mission: {
    elapsed: string
    progress: number
    objectives: number
    completed: number
  }
}

export default function LunCoSimDashboard() {
  const [selectedScenario, setSelectedScenario] = useState('apollo17_harrison')
  const [telemetry, setTelemetry] = useState<TelemetryData | null>(null)
  const [isSimulating, setIsSimulating] = useState(true)

  const scenarios = [
    {
      id: 'apollo17_harrison',
      name: 'Apollo 17 Harrison',
      description: 'Replay Harrison Schmitt\'s EVA traverse with real timing',
      location: 'Taurus-Littrow Valley',
      duration: '7h 15m',
      difficulty: 'Medium'
    },
    {
      id: 'artemis3_landing',
      name: 'Artemis 3 Landing',
      description: '2026 landing site – plume-surface interaction',
      location: 'South Polar Region',
      duration: '2h 30m',
      difficulty: 'High'
    },
    {
      id: 'swarm_12_micros',
      name: 'Swarm 12 Micros',
      description: '12 micro-rovers cooperatively build a radio array',
      location: 'Mare Imbrium',
      duration: '48h',
      difficulty: 'Expert'
    },
    {
      id: 'night_survival',
      name: 'Night Survival',
      description: '14-day lunar-night power / thermal stress test',
      location: 'Shackleton Crater',
      duration: '336h',
      difficulty: 'Extreme'
    }
  ]

  useEffect(() => {
    if (!isSimulating) return

    const interval = setInterval(() => {
      setTelemetry({
        timestamp: new Date().toISOString(),
        rover: {
          name: 'LunRover-1',
          position: {
            x: Math.random() * 1000,
            y: Math.random() * 1000,
            z: Math.random() * 10
          },
          battery: 75 + Math.random() * 20,
          temperature: -20 + Math.random() * 40,
          signal: 60 + Math.random() * 35,
          status: Math.random() > 0.1 ? 'active' : Math.random() > 0.5 ? 'standby' : 'error'
        },
        environment: {
          temperature: -180 + Math.random() * 120,
          radiation: 0.1 + Math.random() * 0.4,
          gravity: 1.62,
          lighting: Math.random() * 100,
          dust: Math.random() * 50
        },
        mission: {
          elapsed: `${Math.floor(Math.random() * 8)}h ${Math.floor(Math.random() * 60)}m`,
          progress: Math.random() * 100,
          objectives: Math.floor(Math.random() * 10) + 5,
          completed: Math.floor(Math.random() * 8)
        }
      })
    }, 2000)

    return () => clearInterval(interval)
  }, [isSimulating])

  return (
    <div className="space-y-6">
      {/* Scenario Selection */}
      <Card className="bg-slate-800/50 border-slate-700">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Rocket className="h-5 w-5 text-blue-400" />
            Mission Scenarios
          </CardTitle>
          <CardDescription>
            Select and configure lunar surface simulation scenarios
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            {scenarios.map((scenario) => (
              <div
                key={scenario.id}
                className={`p-4 rounded-lg border cursor-pointer transition-all ${
                  selectedScenario === scenario.id
                    ? 'bg-blue-600/20 border-blue-400'
                    : 'bg-slate-700/50 border-slate-600 hover:bg-slate-700'
                }`}
                onClick={() => setSelectedScenario(scenario.id)}
              >
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <h3 className="font-semibold text-white mb-1">{scenario.name}</h3>
                    <p className="text-sm text-gray-400 mb-2">{scenario.description}</p>
                    <div className="flex items-center gap-4 text-xs text-gray-500">
                      <span className="flex items-center gap-1">
                        <MapPin className="h-3 w-3" />
                        {scenario.location}
                      </span>
                      <span className="flex items-center gap-1">
                        <Clock className="h-3 w-3" />
                        {scenario.duration}
                      </span>
                    </div>
                  </div>
                  <Badge 
                    variant={scenario.difficulty === 'Extreme' ? 'destructive' : 
                            scenario.difficulty === 'Expert' ? 'default' : 'secondary'}
                    className="ml-2"
                  >
                    {scenario.difficulty}
                  </Badge>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Real-time Telemetry */}
      {telemetry && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Rover Status */}
          <Card className="bg-slate-800/50 border-slate-700">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Satellite className="h-5 w-5 text-green-400" />
                {telemetry.rover.name} Status
              </CardTitle>
              <CardDescription>
                Real-time rover telemetry and systems status
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-sm text-gray-400">System Status</span>
                <Badge 
                  variant={telemetry.rover.status === 'active' ? 'default' : 
                          telemetry.rover.status === 'standby' ? 'secondary' : 'destructive'}
                  className="flex items-center gap-1"
                >
                  {telemetry.rover.status === 'active' && <CheckCircle className="h-3 w-3" />}
                  {telemetry.rover.status === 'standby' && <Clock className="h-3 w-3" />}
                  {telemetry.rover.status === 'error' && <AlertTriangle className="h-3 w-3" />}
                  {telemetry.rover.status}
                </Badge>
              </div>

              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-sm text-gray-400">Battery</span>
                  <span className="text-sm font-medium">{telemetry.rover.battery.toFixed(1)}%</span>
                </div>
                <Progress value={telemetry.rover.battery} className="h-2" />
              </div>

              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-sm text-gray-400">Temperature</span>
                  <span className="text-sm font-medium">{telemetry.rover.temperature.toFixed(1)}°C</span>
                </div>
                <Progress value={(telemetry.rover.temperature + 50) * 2} className="h-2" />
              </div>

              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-sm text-gray-400">Signal Strength</span>
                  <span className="text-sm font-medium">{telemetry.rover.signal.toFixed(0)}%</span>
                </div>
                <Progress value={telemetry.rover.signal} className="h-2" />
              </div>

              <Separator />

              <div className="space-y-2">
                <div className="text-sm text-gray-400">Position Coordinates</div>
                <div className="grid grid-cols-3 gap-2 text-xs">
                  <div className="bg-slate-700/50 p-2 rounded text-center">
                    <div className="text-gray-500">X</div>
                    <div className="font-mono">{telemetry.rover.position.x.toFixed(1)}</div>
                  </div>
                  <div className="bg-slate-700/50 p-2 rounded text-center">
                    <div className="text-gray-500">Y</div>
                    <div className="font-mono">{telemetry.rover.position.y.toFixed(1)}</div>
                  </div>
                  <div className="bg-slate-700/50 p-2 rounded text-center">
                    <div className="text-gray-500">Z</div>
                    <div className="font-mono">{telemetry.rover.position.z.toFixed(1)}</div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Environmental Conditions */}
          <Card className="bg-slate-800/50 border-slate-700">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Moon className="h-5 w-5 text-purple-400" />
                Environmental Conditions
              </CardTitle>
              <CardDescription>
                Lunar surface environment parameters
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <div className="flex items-center gap-2">
                    <Thermometer className="h-4 w-4 text-blue-400" />
                    <span className="text-sm text-gray-400">Temperature</span>
                  </div>
                  <div className="text-2xl font-bold">
                    {telemetry.environment.temperature.toFixed(1)}°C
                  </div>
                </div>

                <div className="space-y-2">
                  <div className="flex items-center gap-2">
                    <Zap className="h-4 w-4 text-yellow-400" />
                    <span className="text-sm text-gray-400">Radiation</span>
                  </div>
                  <div className="text-2xl font-bold">
                    {telemetry.environment.radiation.toFixed(2)} mSv/h
                  </div>
                </div>

                <div className="space-y-2">
                  <div className="flex items-center gap-2">
                    <Gauge className="h-4 w-4 text-green-400" />
                    <span className="text-sm text-gray-400">Gravity</span>
                  </div>
                  <div className="text-2xl font-bold">
                    {telemetry.environment.gravity} m/s²
                  </div>
                </div>

                <div className="space-y-2">
                  <div className="flex items-center gap-2">
                    <Sun className="h-4 w-4 text-orange-400" />
                    <span className="text-sm text-gray-400">Lighting</span>
                  </div>
                  <div className="text-2xl font-bold">
                    {telemetry.environment.lighting.toFixed(0)}%
                  </div>
                </div>
              </div>

              <Separator />

              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-sm text-gray-400">Dust Density</span>
                  <span className="text-sm font-medium">{telemetry.environment.dust.toFixed(1)}%</span>
                </div>
                <Progress value={telemetry.environment.dust} className="h-2" />
              </div>

              <div className="bg-slate-700/50 p-3 rounded-lg">
                <div className="text-xs text-gray-400 mb-1">Last Updated</div>
                <div className="text-sm font-mono">
                  {new Date(telemetry.timestamp).toLocaleTimeString()}
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Mission Progress */}
          <Card className="bg-slate-800/50 border-slate-700">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Compass className="h-5 w-5 text-orange-400" />
                Mission Progress
              </CardTitle>
              <CardDescription>
                Current mission objectives and completion status
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-sm text-gray-400">Mission Time</span>
                  <span className="text-sm font-medium">{telemetry.mission.elapsed}</span>
                </div>
              </div>

              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-sm text-gray-400">Overall Progress</span>
                  <span className="text-sm font-medium">{telemetry.mission.progress.toFixed(1)}%</span>
                </div>
                <Progress value={telemetry.mission.progress} className="h-3" />
              </div>

              <Separator />

              <div className="space-y-2">
                <div className="text-sm text-gray-400">Objectives</div>
                <div className="space-y-2">
                  <div className="flex items-center justify-between p-2 bg-slate-700/50 rounded">
                    <span className="text-sm">Completed</span>
                    <Badge variant="default">{telemetry.mission.completed}</Badge>
                  </div>
                  <div className="flex items-center justify-between p-2 bg-slate-700/50 rounded">
                    <span className="text-sm">Total</span>
                    <Badge variant="secondary">{telemetry.mission.objectives}</Badge>
                  </div>
                </div>
              </div>

              <Separator />

              <div className="space-y-2">
                <Button 
                  onClick={() => setIsSimulating(!isSimulating)}
                  className="w-full"
                  variant={isSimulating ? "destructive" : "default"}
                >
                  {isSimulating ? (
                    <>
                      <Activity className="h-4 w-4 mr-2" />
                      Pause Simulation
                    </>
                  ) : (
                    <>
                      <Rocket className="h-4 w-4 mr-2" />
                      Resume Simulation
                    </>
                  )}
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  )
}