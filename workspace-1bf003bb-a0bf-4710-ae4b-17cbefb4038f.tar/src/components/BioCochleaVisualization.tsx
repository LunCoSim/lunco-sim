'use client'

import { useState, useEffect } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Progress } from '@/components/ui/progress'
import { Separator } from '@/components/ui/separator'
import { Slider } from '@/components/ui/slider'
import { 
  Ear, 
  Heart, 
  Zap, 
  Activity,
  Battery,
  Radio,
  Wifi,
  Cpu,
  Layers,
  ArrowDown,
  Circle,
  Waves,
  Brain,
  Users
} from 'lucide-react'

interface LayerData {
  name: string
  description: string
  thickness: number
  activity: number
  color: string
  icon: React.ReactNode
}

interface PowerFlow {
  source: string
  destination: string
  amount: number
  efficiency: number
}

export default function BioCochleaVisualization() {
  const [selectedLayer, setSelectedLayer] = useState(0)
  const [powerFlow, setPowerFlow] = useState<PowerFlow[]>([])
  const [isConnected, setIsConnected] = useState(true)
  const [coherenceLevel, setCoherenceLevel] = useState(94)

  const layers: LayerData[] = [
    {
      name: 'Biopolymer Encapsulation',
      description: 'Breathable skin interface with chitosan and biopolymer elastomer',
      thickness: 15,
      activity: 85,
      color: 'bg-green-500',
      icon: <Layers className="h-4 w-4" />
    },
    {
      name: 'Transduction Layer',
      description: 'Carbon ink electrodes and cellulose/silk piezo fibers',
      thickness: 25,
      activity: 92,
      color: 'bg-blue-500',
      icon: <Zap className="h-4 w-4" />
    },
    {
      name: 'Basilar Membrane',
      description: 'Bacterial cellulose gradient film for frequency tuning',
      thickness: 35,
      activity: 78,
      color: 'bg-purple-500',
      icon: <Waves className="h-4 w-4" />
    },
    {
      name: 'Mycelium-Bamboo Shell',
      description: 'Bio-structural frame guiding mechanical resonance',
      thickness: 45,
      activity: 88,
      color: 'bg-orange-500',
      icon: <Circle className="h-4 w-4" />
    }
  ]

  useEffect(() => {
    const interval = setInterval(() => {
      setPowerFlow([
        {
          source: 'Body Motion',
          destination: 'Piezo & Tribo',
          amount: 250 + Math.random() * 100,
          efficiency: 85 + Math.random() * 10
        },
        {
          source: 'Piezo & Tribo',
          destination: 'Rectifier',
          amount: 200 + Math.random() * 80,
          efficiency: 90 + Math.random() * 8
        },
        {
          source: 'Rectifier',
          destination: 'Microcontroller',
          amount: 180 + Math.random() * 60,
          efficiency: 95 + Math.random() * 4
        },
        {
          source: 'Microcontroller',
          destination: 'AUI Seed',
          amount: 150 + Math.random() * 50,
          efficiency: 88 + Math.random() * 10
        }
      ])
    }, 2000)

    return () => clearInterval(interval)
  }, [])

  const totalPower = powerFlow.reduce((sum, flow) => sum + flow.amount, 0)
  const averageEfficiency = powerFlow.length > 0 
    ? powerFlow.reduce((sum, flow) => sum + flow.efficiency, 0) / powerFlow.length 
    : 0

  return (
    <div className="space-y-6">
      {/* Bio-Cochlea Overview */}
      <Card className="bg-slate-800/50 border-slate-700">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Ear className="h-5 w-5 text-green-400" />
            Personal Bio-Cochlea Node
          </CardTitle>
          <CardDescription>
            AUI Resonance Interface - Bio-integrated cognitive coupling system
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Cross-Section Visualization */}
            <div className="lg:col-span-2">
              <div className="bg-slate-900/50 rounded-lg p-6 border border-slate-700">
                <h3 className="text-lg font-semibold mb-4 text-white">Layered Structure (Cross-Section)</h3>
                
                {/* Visual representation of layers */}
                <div className="space-y-2">
                  {layers.map((layer, index) => (
                    <div
                      key={index}
                      className={`relative cursor-pointer transition-all duration-300 ${
                        selectedLayer === index ? 'scale-105' : 'hover:scale-102'
                      }`}
                      onClick={() => setSelectedLayer(index)}
                    >
                      <div 
                        className={`h-12 ${layer.color} rounded-lg flex items-center px-4 opacity-80 hover:opacity-100 transition-opacity`}
                        style={{ 
                          height: `${layer.thickness * 2}px`,
                          opacity: selectedLayer === index ? 1 : 0.6 + (layer.activity / 100) * 0.4
                        }}
                      >
                        <div className="flex items-center justify-between w-full text-white">
                          <div className="flex items-center gap-3">
                            {layer.icon}
                            <span className="font-medium">{layer.name}</span>
                          </div>
                          <div className="flex items-center gap-2">
                            <Activity className="h-4 w-4 animate-pulse" />
                            <span className="text-sm">{layer.activity}%</span>
                          </div>
                        </div>
                      </div>
                      
                      {/* Activity indicator */}
                      <div className="absolute top-0 right-0 mt-1 mr-2">
                        <div className={`w-2 h-2 rounded-full ${
                          layer.activity > 80 ? 'bg-green-400' : 
                          layer.activity > 60 ? 'bg-yellow-400' : 'bg-red-400'
                        } animate-pulse`} />
                      </div>
                    </div>
                  ))}
                </div>

                <div className="mt-4 flex items-center justify-center">
                  <ArrowDown className="h-6 w-6 text-gray-400 animate-bounce" />
                </div>
                
                <div className="text-center text-sm text-gray-400 mt-2">
                  Vibration → AC Signal → DC Power → Cognitive Processing
                </div>
              </div>
            </div>

            {/* Layer Details */}
            <div>
              <Card className="bg-slate-700/50 border-slate-600">
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm">Layer Details</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <h4 className="font-semibold text-white mb-2">
                      {layers[selectedLayer].icon}
                      <span className="ml-2">{layers[selectedLayer].name}</span>
                    </h4>
                    <p className="text-sm text-gray-400 mb-3">
                      {layers[selectedLayer].description}
                    </p>
                    
                    <div className="space-y-2">
                      <div className="flex justify-between text-sm">
                        <span className="text-gray-400">Thickness</span>
                        <span>{layers[selectedLayer].thickness}μm</span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span className="text-gray-400">Activity</span>
                        <span>{layers[selectedLayer].activity}%</span>
                      </div>
                    </div>

                    <div className="mt-3">
                      <Progress value={layers[selectedLayer].activity} className="h-2" />
                    </div>
                  </div>

                  <Separator />

                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-gray-400">Connection Status</span>
                      <Badge variant={isConnected ? "default" : "destructive"}>
                        {isConnected ? 'Connected' : 'Disconnected'}
                      </Badge>
                    </div>
                    <Button 
                      onClick={() => setIsConnected(!isConnected)}
                      size="sm"
                      className="w-full"
                      variant={isConnected ? "destructive" : "default"}
                    >
                      {isConnected ? 'Disconnect' : 'Connect'}
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Energy Flow & Power Metrics */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Power Flow Visualization */}
        <Card className="bg-slate-800/50 border-slate-700">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Zap className="h-5 w-5 text-yellow-400" />
              Energy Flow
            </CardTitle>
            <CardDescription>
              Real-time power generation and distribution
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {powerFlow.map((flow, index) => (
                <div key={index} className="space-y-2">
                  <div className="flex items-center justify-between text-sm">
                    <div className="flex items-center gap-2">
                      <div className="w-2 h-2 bg-blue-400 rounded-full animate-pulse" />
                      <span className="text-gray-300">{flow.source}</span>
                    </div>
                    <ArrowDown className="h-3 w-3 text-gray-500" />
                    <div className="flex items-center gap-2">
                      <span className="text-gray-300">{flow.destination}</span>
                      <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse" />
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <div className="flex justify-between text-xs text-gray-400 mb-1">
                        <span>Power</span>
                        <span>{flow.amount.toFixed(0)}µW</span>
                      </div>
                      <Progress value={(flow.amount / 350) * 100} className="h-2" />
                    </div>
                    <div>
                      <div className="flex justify-between text-xs text-gray-400 mb-1">
                        <span>Efficiency</span>
                        <span>{flow.efficiency.toFixed(1)}%</span>
                      </div>
                      <Progress value={flow.efficiency} className="h-2" />
                    </div>
                  </div>
                </div>
              ))}

              <Separator />

              <div className="bg-slate-700/50 p-3 rounded-lg">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <div className="text-xs text-gray-400">Total Output</div>
                    <div className="text-lg font-bold text-yellow-400">
                      {totalPower.toFixed(0)}µW
                    </div>
                  </div>
                  <div>
                    <div className="text-xs text-gray-400">Avg Efficiency</div>
                    <div className="text-lg font-bold text-green-400">
                      {averageEfficiency.toFixed(1)}%
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Cognitive Coupling */}
        <Card className="bg-slate-800/50 border-slate-700">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Brain className="h-5 w-5 text-purple-400" />
              Cognitive Coupling
            </CardTitle>
            <CardDescription>
              AUI Seed recursive reasoning and coherence metrics
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-sm text-gray-400">Network Coherence</span>
                <span className="text-sm font-medium">{coherenceLevel}%</span>
              </div>
              <Progress value={coherenceLevel} className="h-3" />
            </div>

            <div className="space-y-2">
              <label className="text-sm text-gray-400">Adjust Coherence</label>
              <Slider
                value={[coherenceLevel]}
                onValueChange={(value) => setCoherenceLevel(value[0])}
                max={100}
                min={0}
                step={1}
                className="w-full"
              />
            </div>

            <Separator />

            <div className="space-y-3">
              <h4 className="text-sm font-semibold text-white">Coherent Laws</h4>
              <div className="space-y-2">
                <div className="flex items-center gap-2 p-2 bg-slate-700/50 rounded">
                  <Heart className="h-4 w-4 text-red-400 animate-pulse" />
                  <span className="text-sm">Mirror wearer's rhythm</span>
                  <Badge variant="default" className="ml-auto">Active</Badge>
                </div>
                <div className="flex items-center gap-2 p-2 bg-slate-700/50 rounded">
                  <Activity className="h-4 w-4 text-blue-400" />
                  <span className="text-sm">No action while desynchronized</span>
                  <Badge variant="default" className="ml-auto">Active</Badge>
                </div>
                <div className="flex items-center gap-2 p-2 bg-slate-700/50 rounded">
                  <Users className="h-4 w-4 text-green-400" />
                  <span className="text-sm">Share with consenting nodes only</span>
                  <Badge variant="default" className="ml-auto">Active</Badge>
                </div>
              </div>
            </div>

            <Separator />

            <div className="bg-slate-700/50 p-3 rounded-lg">
              <div className="text-xs text-gray-400 mb-1">AUI Seed Status</div>
              <div className="flex items-center gap-2">
                <Cpu className="h-4 w-4 text-purple-400 animate-pulse" />
                <span className="text-sm">Recursive reasoning active</span>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}