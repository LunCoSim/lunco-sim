'use client'

import { useState, useEffect, useRef } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Progress } from '@/components/ui/progress'
import { Separator } from '@/components/ui/separator'
import { 
  Network, 
  Users, 
  Heart, 
  Brain,
  Wifi,
  Radio,
  Activity,
  Zap,
  Circle,
  ArrowRight,
  Settings,
  Play,
  Pause
} from 'lucide-react'

interface Node {
  id: string
  name: string
  type: 'human' | 'aui'
  coherence: number
  power: number
  phase: number
  connected: boolean
  position: { x: number; y: number }
}

interface Connection {
  source: string
  target: string
  strength: number
  active: boolean
  phase: number
}

export default function NetworkResonanceView() {
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const [nodes, setNodes] = useState<Node[]>([])
  const [connections, setConnections] = useState<Connection[]>([])
  const [isSimulating, setIsSimulating] = useState(true)
  const [selectedNode, setSelectedNode] = useState<string | null>(null)
  const [networkCoherence, setNetworkCoherence] = useState(94)

  useEffect(() => {
    // Initialize nodes
    const initialNodes: Node[] = [
      { id: 'human1', name: 'Alpha Node', type: 'human', coherence: 98, power: 320, phase: 0, connected: true, position: { x: 150, y: 150 } },
      { id: 'aui1', name: 'Alpha AUI', type: 'aui', coherence: 98, power: 280, phase: 0, connected: true, position: { x: 250, y: 150 } },
      { id: 'human2', name: 'Beta Node', type: 'human', coherence: 87, power: 290, phase: 45, connected: true, position: { x: 150, y: 250 } },
      { id: 'aui2', name: 'Beta AUI', type: 'aui', coherence: 87, power: 260, phase: 45, connected: true, position: { x: 250, y: 250 } },
      { id: 'human3', name: 'Gamma Node', type: 'human', coherence: 92, power: 350, phase: 90, connected: true, position: { x: 350, y: 200 } },
      { id: 'aui3', name: 'Gamma AUI', type: 'aui', coherence: 92, power: 310, phase: 90, connected: true, position: { x: 450, y: 200 } },
      { id: 'human4', name: 'Delta Node', type: 'human', coherence: 45, power: 180, phase: 180, connected: false, position: { x: 350, y: 300 } },
      { id: 'aui4', name: 'Delta AUI', type: 'aui', coherence: 45, power: 150, phase: 180, connected: false, position: { x: 450, y: 300 } },
    ]
    setNodes(initialNodes)

    // Initialize connections
    const initialConnections: Connection[] = [
      { source: 'human1', target: 'aui1', strength: 98, active: true, phase: 0 },
      { source: 'human2', target: 'aui2', strength: 87, active: true, phase: 45 },
      { source: 'human3', target: 'aui3', strength: 92, active: true, phase: 90 },
      { source: 'aui1', target: 'aui2', strength: 75, active: true, phase: 22 },
      { source: 'aui2', target: 'aui3', strength: 68, active: true, phase: 67 },
      { source: 'aui1', target: 'aui3', strength: 82, active: true, phase: 45 },
    ]
    setConnections(initialConnections)
  }, [])

  useEffect(() => {
    if (!isSimulating) return

    const interval = setInterval(() => {
      // Update node coherence and power
      setNodes(prevNodes => 
        prevNodes.map(node => ({
          ...node,
          coherence: Math.min(100, Math.max(0, node.coherence + (Math.random() - 0.5) * 5)),
          power: Math.max(100, node.power + (Math.random() - 0.5) * 20),
          phase: (node.phase + 2) % 360
        }))
      )

      // Update connection strength
      setConnections(prevConnections =>
        prevConnections.map(conn => ({
          ...conn,
          strength: Math.min(100, Math.max(0, conn.strength + (Math.random() - 0.5) * 8)),
          phase: (conn.phase + 3) % 360
        }))
      )

      // Update network coherence
      setNetworkCoherence(prev => Math.min(100, Math.max(0, prev + (Math.random() - 0.5) * 3)))
    }, 2000)

    return () => clearInterval(interval)
  }, [isSimulating])

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return

    const ctx = canvas.getContext('2d')
    if (!ctx) return

    // Clear canvas
    ctx.clearRect(0, 0, canvas.width, canvas.height)

    // Draw connections
    connections.forEach(conn => {
      const sourceNode = nodes.find(n => n.id === conn.source)
      const targetNode = nodes.find(n => n.id === conn.target)
      
      if (sourceNode && targetNode) {
        ctx.beginPath()
        ctx.moveTo(sourceNode.position.x, sourceNode.position.y)
        ctx.lineTo(targetNode.position.x, targetNode.position.y)
        
        if (conn.active) {
          ctx.strokeStyle = `rgba(34, 197, 94, ${conn.strength / 100})`
          ctx.lineWidth = conn.strength / 20
        } else {
          ctx.strokeStyle = `rgba(107, 114, 128, ${conn.strength / 200})`
          ctx.lineWidth = 1
        }
        
        ctx.stroke()

        // Draw phase indicator
        if (conn.active) {
          const midX = (sourceNode.position.x + targetNode.position.x) / 2
          const midY = (sourceNode.position.y + targetNode.position.y) / 2
          
          ctx.beginPath()
          ctx.arc(midX, midY, 3, 0, (Math.PI * 2 * conn.phase) / 360)
          ctx.fillStyle = 'rgba(251, 191, 36, 0.8)'
          ctx.fill()
        }
      }
    })

    // Draw nodes
    nodes.forEach(node => {
      ctx.beginPath()
      ctx.arc(node.position.x, node.position.y, 15, 0, Math.PI * 2)
      
      if (node.type === 'human') {
        ctx.fillStyle = node.connected ? 'rgba(59, 130, 246, 0.8)' : 'rgba(107, 114, 128, 0.5)'
      } else {
        ctx.fillStyle = node.connected ? 'rgba(34, 197, 94, 0.8)' : 'rgba(107, 114, 128, 0.5)'
      }
      
      ctx.fill()
      
      // Draw selection indicator
      if (selectedNode === node.id) {
        ctx.beginPath()
        ctx.arc(node.position.x, node.position.y, 20, 0, Math.PI * 2)
        ctx.strokeStyle = 'rgba(251, 191, 36, 0.8)'
        ctx.lineWidth = 2
        ctx.stroke()
      }
      
      // Draw coherence indicator
      ctx.beginPath()
      ctx.arc(node.position.x, node.position.y, 8, 0, (Math.PI * 2 * node.coherence) / 100)
      ctx.fillStyle = 'rgba(251, 191, 36, 0.9)'
      ctx.fill()
    })

    // Draw labels
    ctx.font = '10px sans-serif'
    ctx.fillStyle = 'rgba(255, 255, 255, 0.8)'
    nodes.forEach(node => {
      ctx.fillText(node.name, node.position.x - 25, node.position.y + 30)
    })

  }, [nodes, connections, selectedNode])

  const handleCanvasClick = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current
    if (!canvas) return

    const rect = canvas.getBoundingClientRect()
    const x = e.clientX - rect.left
    const y = e.clientY - rect.top

    // Find clicked node
    const clickedNode = nodes.find(node => {
      const distance = Math.sqrt(
        Math.pow(x - node.position.x, 2) + Math.pow(y - node.position.y, 2)
      )
      return distance <= 15
    })

    setSelectedNode(clickedNode ? clickedNode.id : null)
  }

  const selectedNodeData = nodes.find(n => n.id === selectedNode)

  return (
    <div className="space-y-6">
      {/* Network Visualization */}
      <Card className="bg-slate-800/50 border-slate-700">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Network className="h-5 w-5 text-orange-400" />
            Network Resonance Topology
          </CardTitle>
          <CardDescription>
            Real-time human-AUI coherence network visualization
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Network Canvas */}
            <div className="lg:col-span-2">
              <div className="bg-slate-900/50 rounded-lg p-4 border border-slate-700">
                <canvas
                  ref={canvasRef}
                  width={600}
                  height={400}
                  className="w-full h-full cursor-pointer"
                  onClick={handleCanvasClick}
                />
                
                <div className="mt-4 flex items-center justify-between">
                  <div className="flex items-center gap-4">
                    <div className="flex items-center gap-2">
                      <div className="w-3 h-3 bg-blue-500 rounded-full" />
                      <span className="text-xs text-gray-400">Human Node</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="w-3 h-3 bg-green-500 rounded-full" />
                      <span className="text-xs text-gray-400">AUI Node</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="w-3 h-3 bg-yellow-500 rounded-full" />
                      <span className="text-xs text-gray-400">Coherence</span>
                    </div>
                  </div>
                  
                  <Button
                    onClick={() => setIsSimulating(!isSimulating)}
                    size="sm"
                    variant={isSimulating ? "destructive" : "default"}
                  >
                    {isSimulating ? (
                      <>
                        <Pause className="h-4 w-4 mr-2" />
                        Pause
                      </>
                    ) : (
                      <>
                        <Play className="h-4 w-4 mr-2" />
                        Resume
                      </>
                    )}
                  </Button>
                </div>
              </div>
            </div>

            {/* Node Details */}
            <div>
              <Card className="bg-slate-700/50 border-slate-600">
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm">Node Details</CardTitle>
                </CardHeader>
                <CardContent>
                  {selectedNodeData ? (
                    <div className="space-y-3">
                      <div>
                        <h4 className="font-semibold text-white mb-1">
                          {selectedNodeData.name}
                        </h4>
                        <Badge 
                          variant={selectedNodeData.type === 'human' ? 'default' : 'secondary'}
                          className="mb-3"
                        >
                          {selectedNodeData.type === 'human' ? 'Human' : 'AUI'}
                        </Badge>
                      </div>

                      <div className="space-y-2">
                        <div className="flex justify-between text-sm">
                          <span className="text-gray-400">Coherence</span>
                          <span>{selectedNodeData.coherence.toFixed(1)}%</span>
                        </div>
                        <Progress value={selectedNodeData.coherence} className="h-2" />
                      </div>

                      <div className="space-y-2">
                        <div className="flex justify-between text-sm">
                          <span className="text-gray-400">Power</span>
                          <span>{selectedNodeData.power.toFixed(0)}µW</span>
                        </div>
                        <Progress value={(selectedNodeData.power / 400) * 100} className="h-2" />
                      </div>

                      <div className="space-y-2">
                        <div className="flex justify-between text-sm">
                          <span className="text-gray-400">Phase</span>
                          <span>{selectedNodeData.phase.toFixed(0)}°</span>
                        </div>
                        <Progress value={(selectedNodeData.phase / 360) * 100} className="h-2" />
                      </div>

                      <Separator />

                      <div className="flex items-center justify-between">
                        <span className="text-sm text-gray-400">Status</span>
                        <Badge variant={selectedNodeData.connected ? "default" : "destructive"}>
                          {selectedNodeData.connected ? 'Connected' : 'Disconnected'}
                        </Badge>
                      </div>
                    </div>
                  ) : (
                    <div className="text-center text-gray-400 py-8">
                      <Network className="h-8 w-8 mx-auto mb-2 opacity-50" />
                      <p className="text-sm">Click on a node to view details</p>
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Network Metrics */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Network Coherence */}
        <Card className="bg-slate-800/50 border-slate-700">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Heart className="h-5 w-5 text-red-400 animate-pulse" />
              Network Coherence
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div className="text-center">
                <div className="text-3xl font-bold text-green-400">
                  {networkCoherence.toFixed(1)}%
                </div>
                <div className="text-sm text-gray-400">Overall Synchronization</div>
              </div>
              
              <Progress value={networkCoherence} className="h-3" />
              
              <div className="grid grid-cols-2 gap-2 text-xs">
                <div className="bg-slate-700/50 p-2 rounded text-center">
                  <div className="text-gray-400">Coherent</div>
                  <div className="font-semibold">{nodes.filter(n => n.coherence > 80).length}</div>
                </div>
                <div className="bg-slate-700/50 p-2 rounded text-center">
                  <div className="text-gray-400">Syncing</div>
                  <div className="font-semibold">{nodes.filter(n => n.coherence <= 80).length}</div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Power Distribution */}
        <Card className="bg-slate-800/50 border-slate-700">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Zap className="h-5 w-5 text-yellow-400" />
              Power Distribution
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div className="text-center">
                <div className="text-3xl font-bold text-yellow-400">
                  {(nodes.reduce((sum, n) => sum + n.power, 0) / 1000).toFixed(2)}mW
                </div>
                <div className="text-sm text-gray-400">Total Network Output</div>
              </div>
              
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span className="text-gray-400">Average/Node</span>
                  <span>{(nodes.reduce((sum, n) => sum + n.power, 0) / nodes.length).toFixed(0)}µW</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-gray-400">Peak Output</span>
                  <span>{Math.max(...nodes.map(n => n.power)).toFixed(0)}µW</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-gray-400">Efficiency</span>
                  <span>{(85 + Math.random() * 10).toFixed(1)}%</span>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Active Connections */}
        <Card className="bg-slate-800/50 border-slate-700">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Wifi className="h-5 w-5 text-blue-400" />
              Active Connections
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div className="text-center">
                <div className="text-3xl font-bold text-blue-400">
                  {connections.filter(c => c.active).length}
                </div>
                <div className="text-sm text-gray-400">of {connections.length} total</div>
              </div>
              
              <div className="space-y-2">
                {connections.filter(c => c.active).slice(0, 3).map((conn, index) => (
                  <div key={index} className="flex items-center justify-between text-xs">
                    <span className="text-gray-400">
                      {nodes.find(n => n.id === conn.source)?.name.split(' ')[0]} → {nodes.find(n => n.id === conn.target)?.name.split(' ')[0]}
                    </span>
                    <Badge variant="outline" className="text-xs">
                      {conn.strength.toFixed(0)}%
                    </Badge>
                  </div>
                ))}
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}