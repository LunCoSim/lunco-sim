'use client'

import { useState, useEffect, useRef } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Progress } from '@/components/ui/progress'
import { Separator } from '@/components/ui/separator'
import { ScrollArea } from '@/components/ui/scroll-area'
import { 
  Command, 
  Users, 
  Heart, 
  Brain,
  Activity,
  AlertTriangle,
  CheckCircle,
  Rocket,
  Moon,
  Ear,
  Network,
  Zap,
  Radio,
  MapPin,
  TrendingUp,
  TrendingDown,
  ArrowRight,
  Circle,
  Satellite,
  Shield,
  Battery,
  Wind,
  Thermometer,
  Timer,
  Target,
  Play,
  Pause
} from 'lucide-react'

interface CrewVitals {
  id: string
  name: string
  role: string
  heartRate: number
  hrv: number
  bloodOxygen: number
  temperature: number
  stressLevel: number
  status: 'nominal' | 'elevated' | 'critical'
  evaActive: boolean
  location: { x: number; y: number; z: number }
  suitIntegrity: number
}

interface NetworkMetrics {
  avgCoherence: number
  aggregateHRV: number
  impactFactor: number
  correlation: number
  activeNodes: number
  totalPower: number
}

interface RoverStatus {
  id: string
  name: string
  battery: number
  signal: number
  status: 'active' | 'standby' | 'error'
  task: string
  location: { x: number; y: number }
  efficiency: number
}

interface Alert {
  id: string
  type: 'critical' | 'warning' | 'info'
  source: 'crew' | 'network' | 'rover' | 'system'
  message: string
  timestamp: string
  acknowledged: boolean
}

export default function MissionCommandCenter() {
  const [crew, setCrew] = useState<CrewVitals[]>([])
  const [network, setNetwork] = useState<NetworkMetrics | null>(null)
  const [rovers, setRovers] = useState<RoverStatus[]>([])
  const [alerts, setAlerts] = useState<Alert[]>([])
  const [isMonitoring, setIsMonitoring] = useState(true)
  const [selectedSystem, setSelectedSystem] = useState<'overview' | 'crew' | 'network' | 'rovers'>('overview')
  const canvasRef = useRef<HTMLCanvasElement>(null)

  // Initialize crew data
  useEffect(() => {
    const initialCrew: CrewVitals[] = [
      {
        id: 'astro-1',
        name: 'Cmdr. Reyes',
        role: 'Mission Commander',
        heartRate: 72,
        hrv: 65,
        bloodOxygen: 98,
        temperature: 36.8,
        stressLevel: 25,
        status: 'nominal',
        evaActive: true,
        location: { x: 1250, y: 890, z: 15 },
        suitIntegrity: 98
      },
      {
        id: 'astro-2',
        name: 'Eng. Patel',
        role: 'EVA Specialist',
        heartRate: 85,
        hrv: 45,
        bloodOxygen: 96,
        temperature: 37.2,
        stressLevel: 55,
        status: 'elevated',
        evaActive: true,
        location: { x: 980, y: 1200, z: 8 },
        suitIntegrity: 95
      },
      {
        id: 'astro-3',
        name: 'Sci. Novak',
        role: 'Science Officer',
        heartRate: 68,
        hrv: 72,
        bloodOxygen: 99,
        temperature: 36.6,
        stressLevel: 20,
        status: 'nominal',
        evaActive: false,
        location: { x: 0, y: 0, z: 0 },
        suitIntegrity: 100
      }
    ]
    setCrew(initialCrew)

    const initialRovers: RoverStatus[] = [
      {
        id: 'rover-1',
        name: 'LunRover-Alpha',
        battery: 78,
        signal: 92,
        status: 'active',
        task: 'Solar Panel Installation',
        location: { x: 1200, y: 850 },
        efficiency: 87
      },
      {
        id: 'rover-2',
        name: 'LunRover-Beta',
        battery: 65,
        signal: 78,
        status: 'active',
        task: 'Sample Collection',
        location: { x: 950, y: 1150 },
        efficiency: 72
      }
    ]
    setRovers(initialRovers)
  }, [])

  // Real-time data simulation
  useEffect(() => {
    if (!isMonitoring) return

    const interval = setInterval(() => {
      // Update crew vitals
      setCrew(prevCrew =>
        prevCrew.map(member => {
          const newHeartRate = Math.max(60, Math.min(100, member.heartRate + (Math.random() - 0.5) * 8))
          const newHRV = Math.max(20, Math.min(100, member.hrv + (Math.random() - 0.5) * 10))
          const newStress = Math.max(0, Math.min(100, member.stressLevel + (Math.random() - 0.5) * 8))
          
          let status: 'nominal' | 'elevated' | 'critical' = 'nominal'
          if (newHeartRate > 90 || newHRV < 30 || newStress > 70) {
            status = 'critical'
          } else if (newHeartRate > 80 || newHRV < 45 || newStress > 50) {
            status = 'elevated'
          }

          return {
            ...member,
            heartRate: newHeartRate,
            hrv: newHRV,
            stressLevel: newStress,
            status,
            location: member.evaActive ? {
              x: member.location.x + (Math.random() - 0.5) * 20,
              y: member.location.y + (Math.random() - 0.5) * 20,
              z: member.location.z + (Math.random() - 0.5) * 2
            } : member.location,
            suitIntegrity: member.evaActive ? Math.max(90, member.suitIntegrity - Math.random() * 0.1) : member.suitIntegrity
          }
        })
      )

      // Calculate aggregate HRV and network metrics
      const activeCrew = crew.filter(c => c.evaActive)
      const aggregateHRV = activeCrew.length > 0 
        ? activeCrew.reduce((sum, c) => sum + c.hrv, 0) / activeCrew.length 
        : 65

      const newNetwork: NetworkMetrics = {
        avgCoherence: 85 + Math.random() * 10 + (aggregateHRV - 50) * 0.2,
        aggregateHRV,
        impactFactor: 0.8 + (aggregateHRV / 100) * 0.4,
        correlation: 0.7 + Math.random() * 0.2,
        activeNodes: 6 + Math.floor(Math.random() * 3),
        totalPower: 2.0 + Math.random() * 1.5
      }
      setNetwork(newNetwork)

      // Update rover status based on crew HRV
      setRovers(prevRovers =>
        prevRovers.map(rover => ({
          ...rover,
          battery: Math.max(0, rover.battery - Math.random() * 0.3),
          efficiency: Math.min(100, Math.max(50, rover.efficiency + (aggregateHRV - 50) * 0.5)),
          signal: Math.max(70, Math.min(100, rover.signal + (Math.random() - 0.5) * 5))
        }))
      )

      // Generate alerts based on system status
      const newAlerts: Alert[] = []
      
      crew.forEach(member => {
        if (member.status === 'critical') {
          newAlerts.push({
            id: `alert-${Date.now()}-${member.id}`,
            type: 'critical',
            source: 'crew',
            message: `Critical vitals for ${member.name} - HR: ${member.heartRate}, HRV: ${member.hrv}`,
            timestamp: new Date().toISOString(),
            acknowledged: false
          })
        } else if (member.status === 'elevated' && Math.random() > 0.7) {
          newAlerts.push({
            id: `alert-${Date.now()}-${member.id}`,
            type: 'warning',
            source: 'crew',
            message: `Elevated stress levels for ${member.name}`,
            timestamp: new Date().toISOString(),
            acknowledged: false
          })
        }
      })

      if (aggregateHRV < 40) {
        newAlerts.push({
          id: `alert-${Date.now()}-network`,
          type: 'warning',
          source: 'network',
          message: `Low aggregate HRV (${aggregateHRV.toFixed(0)}ms) affecting network coherence`,
          timestamp: new Date().toISOString(),
          acknowledged: false
        })
      }

      setAlerts(prev => [...newAlerts, ...prev].slice(0, 20)) // Keep last 20 alerts
    }, 2000)

    return () => clearInterval(interval)
  }, [isMonitoring, crew])

  // Animated flow diagram
  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return

    const ctx = canvas.getContext('2d')
    if (!ctx) return

    let animationId: number
    let time = 0

    const animate = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height)
      
      // Draw connection lines
      ctx.strokeStyle = 'rgba(34, 197, 94, 0.3)'
      ctx.lineWidth = 2
      
      // Crew to Network connections
      crew.forEach((member, index) => {
        if (member.evaActive) {
          const crewX = 50 + index * 80
          const crewY = 100
          const networkX = canvas.width / 2
          const networkY = canvas.height / 2
          
          ctx.beginPath()
          ctx.moveTo(crewX, crewY)
          ctx.lineTo(networkX, networkY)
          ctx.stroke()
          
          // Animated pulse
          const pulseX = crewX + (networkX - crewX) * ((Math.sin(time * 0.002 + index) + 1) / 2)
          const pulseY = crewY + (networkY - crewY) * ((Math.sin(time * 0.002 + index) + 1) / 2)
          
          ctx.beginPath()
          ctx.arc(pulseX, pulseY, 3, 0, Math.PI * 2)
          ctx.fillStyle = `rgba(251, 191, 36, ${0.5 + Math.sin(time * 0.003 + index) * 0.5})`
          ctx.fill()
        }
      })
      
      // Network to Rover connections
      rovers.forEach((rover, index) => {
        const networkX = canvas.width / 2
        const networkY = canvas.height / 2
        const roverX = canvas.width - 100 - index * 80
        const roverY = canvas.height - 100
        
        ctx.beginPath()
        ctx.moveTo(networkX, networkY)
        ctx.lineTo(roverX, roverY)
        ctx.stroke()
        
        // Animated pulse
        const pulseX = networkX + (roverX - networkX) * ((Math.sin(time * 0.002 + index + 2) + 1) / 2)
        const pulseY = networkY + (roverY - networkY) * ((Math.sin(time * 0.002 + index + 2) + 1) / 2)
        
        ctx.beginPath()
        ctx.arc(pulseX, pulseY, 3, 0, Math.PI * 2)
        ctx.fillStyle = `rgba(59, 130, 246, ${0.5 + Math.sin(time * 0.003 + index + 2) * 0.5})`
        ctx.fill()
      })
      
      time += 16
      animationId = requestAnimationFrame(animate)
    }
    
    animate()
    
    return () => cancelAnimationFrame(animationId)
  }, [crew, rovers])

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'nominal': return 'text-green-400 border-green-400'
      case 'elevated': return 'text-yellow-400 border-yellow-400'
      case 'critical': return 'text-red-400 border-red-400'
      default: return 'text-gray-400 border-gray-400'
    }
  }

  const getAlertIcon = (type: string) => {
    switch (type) {
      case 'critical': return <AlertTriangle className="h-4 w-4 text-red-400" />
      case 'warning': return <AlertTriangle className="h-4 w-4 text-yellow-400" />
      case 'info': return <CheckCircle className="h-4 w-4 text-blue-400" />
      default: return <Activity className="h-4 w-4" />
    }
  }

  const criticalAlerts = alerts.filter(a => a.type === 'critical' && !a.acknowledged)
  const warningAlerts = alerts.filter(a => a.type === 'warning' && !a.acknowledged)

  return (
    <div className="space-y-6">
      {/* Command Header */}
      <Card className="bg-slate-800/50 border-slate-700">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Command className="h-6 w-6 text-purple-400" />
            Mission Command Center
          </CardTitle>
          <CardDescription>
            Unified cognitive system monitoring - Human Bio-Network Lunar Operations
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="flex items-center gap-2">
                <Activity className={`h-4 w-4 ${isMonitoring ? 'text-green-400 animate-pulse' : 'text-gray-400'}`} />
                <span className="text-sm text-gray-400">
                  Systems {isMonitoring ? 'Online' : 'Paused'}
                </span>
              </div>
              {network && (
                <div className="flex items-center gap-2">
                  <Brain className="h-4 w-4 text-blue-400" />
                  <span className="text-sm text-gray-400">
                    Network Coherence: {network.avgCoherence.toFixed(1)}%
                  </span>
                </div>
              )}
              {network && (
                <div className="flex items-center gap-2">
                  <Heart className="h-4 w-4 text-red-400" />
                  <span className="text-sm text-gray-400">
                    Aggregate HRV: {network.aggregateHRV.toFixed(0)}ms
                  </span>
                </div>
              )}
            </div>
            <div className="flex items-center gap-2">
              {criticalAlerts.length > 0 && (
                <Badge variant="destructive" className="animate-pulse">
                  {criticalAlerts.length} Critical
                </Badge>
              )}
              {warningAlerts.length > 0 && (
                <Badge variant="secondary" className="text-yellow-400 border-yellow-400">
                  {warningAlerts.length} Warnings
                </Badge>
              )}
              <Button
                onClick={() => setIsMonitoring(!isMonitoring)}
                variant={isMonitoring ? "destructive" : "default"}
                size="sm"
              >
                {isMonitoring ? (
                  <>
                    <Pause className="h-4 w-4 mr-2" />
                    Pause
                  </>
                ) : (
                  <>
                    <Play className="h-4 w-4 mr-2" />
                    Resume
                  </>
                )}
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Animated Flow Diagram */}
      <Card className="bg-slate-800/50 border-slate-700">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Network className="h-5 w-5 text-green-400" />
            Cognitive Symbiosis Flow
          </CardTitle>
          <CardDescription>
            Real-time bio-network influence on lunar operations
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="relative">
            <canvas
              ref={canvasRef}
              width={800}
              height={300}
              className="w-full h-full border border-slate-600 rounded-lg bg-slate-900/50"
            />
            
            {/* System Labels */}
            <div className="absolute top-4 left-4 flex gap-4">
              {crew.map((member, index) => (
                <div key={member.id} className="text-center">
                  <div className={`w-12 h-12 rounded-full flex items-center justify-center ${
                    member.evaActive ? 'bg-blue-600/50 border border-blue-400' : 'bg-gray-600/50 border border-gray-400'
                  }`}>
                    <Users className="h-6 w-6 text-white" />
                  </div>
                  <div className="text-xs text-gray-400 mt-1">{member.name.split(' ')[0]}</div>
                </div>
              ))}
            </div>
            
            <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2">
              <div className="w-16 h-16 rounded-full bg-purple-600/50 border border-purple-400 flex items-center justify-center">
                <Brain className="h-8 w-8 text-white" />
              </div>
              <div className="text-xs text-gray-400 mt-1 text-center">Bio-Network</div>
            </div>
            
            <div className="absolute bottom-4 right-4 flex gap-4">
              {rovers.map((rover, index) => (
                <div key={rover.id} className="text-center">
                  <div className={`w-12 h-12 rounded-full flex items-center justify-center ${
                    rover.status === 'active' ? 'bg-green-600/50 border border-green-400' : 'bg-gray-600/50 border border-gray-400'
                  }`}>
                    <Rocket className="h-6 w-6 text-white" />
                  </div>
                  <div className="text-xs text-gray-400 mt-1">{rover.name.split('-')[1]}</div>
                </div>
              ))}
            </div>
          </div>
        </CardContent>
      </Card>

      {/* System Status Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Crew Status */}
        <Card className="bg-slate-800/50 border-slate-700">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Users className="h-5 w-5 text-red-400" />
              Crew Systems
            </CardTitle>
            <CardDescription>
              Multi-astronaut vital signs and EVA status
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            {crew.map((member) => (
              <div key={member.id} className="p-3 bg-slate-700/50 rounded-lg">
                <div className="flex items-center justify-between mb-2">
                  <div>
                    <div className="font-semibold text-white text-sm">{member.name}</div>
                    <div className="text-xs text-gray-400">{member.role}</div>
                  </div>
                  <div className="flex items-center gap-2">
                    <Badge variant={member.evaActive ? "default" : "secondary"} className="text-xs">
                      {member.evaActive ? 'EVA' : 'Standby'}
                    </Badge>
                    <Badge 
                      variant="outline" 
                      className={`text-xs ${getStatusColor(member.status)}`}
                    >
                      {member.status}
                    </Badge>
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-2 text-xs">
                  <div>
                    <span className="text-gray-400">HRV:</span>
                    <span className="ml-1 font-medium">{member.hrv}ms</span>
                  </div>
                  <div>
                    <span className="text-gray-400">HR:</span>
                    <span className="ml-1 font-medium">{member.heartRate}bpm</span>
                  </div>
                  <div>
                    <span className="text-gray-400">Stress:</span>
                    <span className="ml-1 font-medium">{member.stressLevel}%</span>
                  </div>
                  <div>
                    <span className="text-gray-400">Integrity:</span>
                    <span className="ml-1 font-medium">{member.suitIntegrity.toFixed(1)}%</span>
                  </div>
                </div>
              </div>
            ))}
          </CardContent>
        </Card>

        {/* Network Status */}
        <Card className="bg-slate-800/50 border-slate-700">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Brain className="h-5 w-5 text-blue-400" />
              Bio-Network Status
            </CardTitle>
            <CardDescription>
              Cognitive coherence and HRV influence
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {network && (
              <>
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-400">Avg Coherence</span>
                    <span className="text-sm font-medium">{network.avgCoherence.toFixed(1)}%</span>
                  </div>
                  <Progress value={network.avgCoherence} className="h-2" />
                </div>
                
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-400">Aggregate HRV</span>
                    <span className="text-sm font-medium">{network.aggregateHRV.toFixed(0)}ms</span>
                  </div>
                  <Progress value={(network.aggregateHRV / 100) * 100} className="h-2" />
                </div>
                
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-400">Impact Factor</span>
                    <span className="text-sm font-medium">{network.impactFactor.toFixed(2)}</span>
                  </div>
                  <Progress value={network.impactFactor * 100} className="h-2" />
                </div>
                
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div>
                    <span className="text-gray-400">Active Nodes:</span>
                    <span className="ml-1 font-medium">{network.activeNodes}</span>
                  </div>
                  <div>
                    <span className="text-gray-400">Power:</span>
                    <span className="ml-1 font-medium">{network.totalPower.toFixed(1)}mW</span>
                  </div>
                </div>
              </>
            )}
          </CardContent>
        </Card>

        {/* Rover Status */}
        <Card className="bg-slate-800/50 border-slate-700">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Rocket className="h-5 w-5 text-green-400" />
              Lunar Operations
            </CardTitle>
            <CardDescription>
              Rover status and task efficiency
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            {rovers.map((rover) => (
              <div key={rover.id} className="p-3 bg-slate-700/50 rounded-lg">
                <div className="flex items-center justify-between mb-2">
                  <div>
                    <div className="font-semibold text-white text-sm">{rover.name}</div>
                    <div className="text-xs text-gray-400">{rover.task}</div>
                  </div>
                  <Badge 
                    variant={rover.status === 'active' ? "default" : "secondary"}
                    className="text-xs"
                  >
                    {rover.status}
                  </Badge>
                </div>
                <div className="grid grid-cols-2 gap-2 text-xs">
                  <div>
                    <span className="text-gray-400">Battery:</span>
                    <span className="ml-1 font-medium">{rover.battery.toFixed(1)}%</span>
                  </div>
                  <div>
                    <span className="text-gray-400">Signal:</span>
                    <span className="ml-1 font-medium">{rover.signal}%</span>
                  </div>
                  <div>
                    <span className="text-gray-400">Efficiency:</span>
                    <span className="ml-1 font-medium">{rover.efficiency.toFixed(1)}%</span>
                  </div>
                  <div>
                    <span className="text-gray-400">Location:</span>
                    <span className="ml-1 font-medium">{rover.location.x},{rover.location.y}</span>
                  </div>
                </div>
              </div>
            ))}
          </CardContent>
        </Card>
      </div>

      {/* Unified Alert System */}
      <Card className="bg-slate-800/50 border-slate-700">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <AlertTriangle className="h-5 w-5 text-orange-400" />
            Unified Alert System
          </CardTitle>
          <CardDescription>
            Cross-system alerts and recommendations
          </CardDescription>
        </CardHeader>
        <CardContent>
          <ScrollArea className="h-48">
            <div className="space-y-2">
              {alerts.length === 0 ? (
                <div className="text-center text-gray-400 py-4">
                  <CheckCircle className="h-8 w-8 mx-auto mb-2 opacity-50" />
                  <p>All systems nominal</p>
                </div>
              ) : (
                alerts.slice(0, 10).map((alert) => (
                  <div
                    key={alert.id}
                    className={`p-3 rounded-lg border ${
                      alert.type === 'critical' ? 'bg-red-900/20 border-red-400' :
                      alert.type === 'warning' ? 'bg-yellow-900/20 border-yellow-400' :
                      'bg-blue-900/20 border-blue-400'
                    }`}
                  >
                    <div className="flex items-start gap-3">
                      {getAlertIcon(alert.type)}
                      <div className="flex-1">
                        <div className="flex items-center justify-between">
                          <span className="font-semibold text-sm">
                            {alert.source.charAt(0).toUpperCase() + alert.source.slice(1)} Alert
                          </span>
                          <span className="text-xs text-gray-400">
                            {new Date(alert.timestamp).toLocaleTimeString()}
                          </span>
                        </div>
                        <div className="text-sm text-gray-300 mt-1">
                          {alert.message}
                        </div>
                      </div>
                      {!alert.acknowledged && (
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => {
                            setAlerts(prev => 
                              prev.map(a => a.id === alert.id ? { ...a, acknowledged: true } : a)
                            )
                          }}
                        >
                          Ack
                        </Button>
                      )}
                    </div>
                  </div>
                ))
              )}
            </div>
          </ScrollArea>
        </CardContent>
      </Card>
    </div>
  )
}