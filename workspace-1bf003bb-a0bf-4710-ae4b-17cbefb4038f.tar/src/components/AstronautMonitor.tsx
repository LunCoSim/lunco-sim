'use client'

import { useState, useEffect } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Progress } from '@/components/ui/progress'
import { Separator } from '@/components/ui/separator'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { ScrollArea } from '@/components/ui/scroll-area'
import { 
  Heart, 
  Activity, 
  Thermometer,
  Droplets,
  Wind,
  Battery,
  Radio,
  MapPin,
  Clock,
  AlertTriangle,
  CheckCircle,
  User,
  Zap,
  Shield,
  Satellite,
  Timer,
  Target,
  TrendingUp,
  TrendingDown,
  AlertCircle,
  Play,
  Pause
} from 'lucide-react'

interface VitalSigns {
  heartRate: number
  bloodOxygen: number
  temperature: number
  respirationRate: number
  bloodPressure: { systolic: number; diastolic: number }
  stressLevel: number
  hydration: number
}

interface SuitTelemetry {
  primaryOxygen: number
  secondaryOxygen: number
  batteryPower: number
  co2Scrubber: number
  internalPressure: number
  externalPressure: number
  communicationSignal: number
  coolingSystem: number
}

interface EVAInfo {
  status: 'preparing' | 'active' | 'completed' | 'emergency'
  duration: string
  startTime: string
  location: { x: number; y: number; z: number }
  currentTask: string
  completedTasks: number
  totalTasks: number
  distanceTraveled: number
  suitIntegrity: number
}

interface AstronautData {
  id: string
  name: string
  role: string
  status: 'nominal' | 'warning' | 'critical'
  vitals: VitalSigns
  suit: SuitTelemetry
  eva: EVAInfo
  lastUpdate: string
}

export default function AstronautMonitor() {
  const [selectedAstronaut, setSelectedAstronaut] = useState<string>('astro1')
  const [astronauts, setAstronauts] = useState<AstronautData[]>([])
  const [isMonitoring, setIsMonitoring] = useState(true)

  useEffect(() => {
    // Initialize astronaut data
    const initialData: AstronautData[] = [
      {
        id: 'astro1',
        name: 'Sarah Chen',
        role: 'Mission Commander',
        status: 'nominal',
        vitals: {
          heartRate: 72,
          bloodOxygen: 98,
          temperature: 36.8,
          respirationRate: 16,
          bloodPressure: { systolic: 120, diastolic: 80 },
          stressLevel: 25,
          hydration: 85
        },
        suit: {
          primaryOxygen: 85,
          secondaryOxygen: 95,
          batteryPower: 78,
          co2Scrubber: 70,
          internalPressure: 4.3,
          externalPressure: 0.0,
          communicationSignal: 92,
          coolingSystem: 65
        },
        eva: {
          status: 'active',
          duration: '2h 45m',
          startTime: '08:30 UTC',
          location: { x: 1250, y: 890, z: 15 },
          currentTask: 'Solar Panel Installation',
          completedTasks: 3,
          totalTasks: 8,
          distanceTraveled: 1250,
          suitIntegrity: 98
        },
        lastUpdate: new Date().toISOString()
      },
      {
        id: 'astro2',
        name: 'Marcus Rodriguez',
        role: 'EVA Specialist',
        status: 'warning',
        vitals: {
          heartRate: 95,
          bloodOxygen: 96,
          temperature: 37.2,
          respirationRate: 20,
          bloodPressure: { systolic: 135, diastolic: 88 },
          stressLevel: 65,
          hydration: 72
        },
        suit: {
          primaryOxygen: 65,
          secondaryOxygen: 90,
          batteryPower: 45,
          co2Scrubber: 55,
          internalPressure: 4.2,
          externalPressure: 0.0,
          communicationSignal: 78,
          coolingSystem: 80
        },
        eva: {
          status: 'active',
          duration: '3h 15m',
          startTime: '08:00 UTC',
          location: { x: 980, y: 1200, z: 8 },
          currentTask: 'Sample Collection',
          completedTasks: 5,
          totalTasks: 7,
          distanceTraveled: 2100,
          suitIntegrity: 95
        },
        lastUpdate: new Date().toISOString()
      },
      {
        id: 'astro3',
        name: 'Dr. Elena Volkov',
        role: 'Science Officer',
        status: 'nominal',
        vitals: {
          heartRate: 68,
          bloodOxygen: 99,
          temperature: 36.6,
          respirationRate: 14,
          bloodPressure: { systolic: 118, diastolic: 78 },
          stressLevel: 20,
          hydration: 90
        },
        suit: {
          primaryOxygen: 92,
          secondaryOxygen: 98,
          batteryPower: 88,
          co2Scrubber: 85,
          internalPressure: 4.4,
          externalPressure: 0.0,
          communicationSignal: 95,
          coolingSystem: 70
        },
        eva: {
          status: 'preparing',
          duration: '0h 0m',
          startTime: '12:00 UTC',
          location: { x: 0, y: 0, z: 0 },
          currentTask: 'Pre-EVA Checks',
          completedTasks: 0,
          totalTasks: 10,
          distanceTraveled: 0,
          suitIntegrity: 100
        },
        lastUpdate: new Date().toISOString()
      }
    ]
    setAstronauts(initialData)
  }, [])

  useEffect(() => {
    if (!isMonitoring) return

    const interval = setInterval(() => {
      setAstronauts(prevAstronauts =>
        prevAstronauts.map(astronaut => {
          // Simulate vital sign fluctuations
          const newVitals = {
            ...astronaut.vitals,
            heartRate: Math.max(60, Math.min(100, astronaut.vitals.heartRate + (Math.random() - 0.5) * 8)),
            bloodOxygen: Math.max(94, Math.min(100, astronaut.vitals.bloodOxygen + (Math.random() - 0.5) * 2)),
            temperature: Math.max(36.0, Math.min(38.0, astronaut.vitals.temperature + (Math.random() - 0.5) * 0.4)),
            respirationRate: Math.max(12, Math.min(24, astronaut.vitals.respirationRate + (Math.random() - 0.5) * 3)),
            stressLevel: Math.max(0, Math.min(100, astronaut.vitals.stressLevel + (Math.random() - 0.5) * 10)),
            hydration: Math.max(60, Math.min(100, astronaut.vitals.hydration - Math.random() * 0.5))
          }

          // Simulate suit telemetry changes
          const newSuit = {
            ...astronaut.suit,
            primaryOxygen: Math.max(0, astronaut.suit.primaryOxygen - Math.random() * 0.3),
            batteryPower: Math.max(0, astronaut.suit.batteryPower - Math.random() * 0.2),
            co2Scrubber: Math.max(0, astronaut.suit.co2Scrubber - Math.random() * 0.4),
            communicationSignal: Math.max(70, Math.min(100, astronaut.suit.communicationSignal + (Math.random() - 0.5) * 5))
          }

          // Update EVA info if active
          const newEVA = astronaut.eva.status === 'active' ? {
            ...astronaut.eva,
            distanceTraveled: astronaut.eva.distanceTraveled + Math.random() * 10,
            suitIntegrity: Math.max(90, astronaut.eva.suitIntegrity - Math.random() * 0.1)
          } : astronaut.eva

          // Determine status based on vitals and suit
          let status: 'nominal' | 'warning' | 'critical' = 'nominal'
          if (
            newVitals.heartRate > 90 || newVitals.heartRate < 60 ||
            newVitals.bloodOxygen < 95 ||
            newVitals.temperature > 37.5 ||
            newSuit.primaryOxygen < 30 ||
            newSuit.batteryPower < 20
          ) {
            status = 'critical'
          } else if (
            newVitals.heartRate > 80 || newVitals.heartRate < 65 ||
            newVitals.bloodOxygen < 97 ||
            newVitals.temperature > 37.0 ||
            newSuit.primaryOxygen < 50 ||
            newSuit.batteryPower < 40 ||
            newVitals.stressLevel > 60
          ) {
            status = 'warning'
          }

          return {
            ...astronaut,
            vitals: newVitals,
            suit: newSuit,
            eva: newEVA,
            status,
            lastUpdate: new Date().toISOString()
          }
        })
      )
    }, 2000)

    return () => clearInterval(interval)
  }, [isMonitoring])

  const selectedAstronautData = astronauts.find(a => a.id === selectedAstronaut)

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'nominal': return 'text-green-400 border-green-400'
      case 'warning': return 'text-yellow-400 border-yellow-400'
      case 'critical': return 'text-red-400 border-red-400'
      default: return 'text-gray-400 border-gray-400'
    }
  }

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'nominal': return <CheckCircle className="h-4 w-4" />
      case 'warning': return <AlertTriangle className="h-4 w-4" />
      case 'critical': return <AlertCircle className="h-4 w-4" />
      default: return <Activity className="h-4 w-4" />
    }
  }

  const getVitalStatus = (value: number, normal: { min: number; max: number }) => {
    if (value < normal.min || value > normal.max) return 'critical'
    if (value < normal.min + 5 || value > normal.max - 5) return 'warning'
    return 'normal'
  }

  return (
    <div className="space-y-6">
      {/* Astronaut Selection */}
      <Card className="bg-slate-800/50 border-slate-700">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <User className="h-5 w-5 text-blue-400" />
            Astronaut Selection
          </CardTitle>
          <CardDescription>
            Select astronaut to monitor detailed vitals and telemetry
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {astronauts.map((astronaut) => (
              <div
                key={astronaut.id}
                className={`p-4 rounded-lg border cursor-pointer transition-all ${
                  selectedAstronaut === astronaut.id
                    ? 'bg-blue-600/20 border-blue-400'
                    : 'bg-slate-700/50 border-slate-600 hover:bg-slate-700'
                }`}
                onClick={() => setSelectedAstronaut(astronaut.id)}
              >
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <h3 className="font-semibold text-white mb-1">{astronaut.name}</h3>
                    <p className="text-sm text-gray-400 mb-2">{astronaut.role}</p>
                    <div className="flex items-center gap-2">
                      <Badge 
                        variant="outline" 
                        className={`${getStatusColor(astronaut.status)} flex items-center gap-1`}
                      >
                        {getStatusIcon(astronaut.status)}
                        {astronaut.status}
                      </Badge>
                      {astronaut.eva.status === 'active' && (
                        <Badge variant="default" className="text-xs">
                          EVA Active
                        </Badge>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {selectedAstronautData && (
        <Tabs defaultValue="vitals" className="space-y-6">
          <TabsList className="grid w-full grid-cols-4 bg-slate-800/50 border border-slate-700">
            <TabsTrigger value="vitals" className="data-[state=active]:bg-red-600">
              <Heart className="h-4 w-4 mr-2" />
              Vital Signs
            </TabsTrigger>
            <TabsTrigger value="suit" className="data-[state=active]:bg-blue-600">
              <Shield className="h-4 w-4 mr-2" />
              Suit Telemetry
            </TabsTrigger>
            <TabsTrigger value="eva" className="data-[state=active]:bg-green-600">
              <MapPin className="h-4 w-4 mr-2" />
              EVA Tracking
            </TabsTrigger>
            <TabsTrigger value="alerts" className="data-[state=active]:bg-orange-600">
              <AlertTriangle className="h-4 w-4 mr-2" />
              Alerts
            </TabsTrigger>
          </TabsList>

          {/* Vital Signs Tab */}
          <TabsContent value="vitals">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Primary Vitals */}
              <Card className="bg-slate-800/50 border-slate-700">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Heart className="h-5 w-5 text-red-400" />
                    Primary Vital Signs
                  </CardTitle>
                  <CardDescription>
                    Real-time monitoring of critical health parameters
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-gray-400">Heart Rate</span>
                      <div className="flex items-center gap-2">
                        <span className="text-lg font-semibold">{selectedAstronautData.vitals.heartRate}</span>
                        <span className="text-sm text-gray-400">bpm</span>
                        <Heart className="h-4 w-4 text-red-400 animate-pulse" />
                      </div>
                    </div>
                    <Progress 
                      value={(selectedAstronautData.vitals.heartRate / 120) * 100} 
                      className="h-2"
                    />
                  </div>

                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-gray-400">Blood Oxygen</span>
                      <div className="flex items-center gap-2">
                        <span className="text-lg font-semibold">{selectedAstronautData.vitals.bloodOxygen}</span>
                        <span className="text-sm text-gray-400">%</span>
                        <Droplets className="h-4 w-4 text-blue-400" />
                      </div>
                    </div>
                    <Progress value={selectedAstronautData.vitals.bloodOxygen} className="h-2" />
                  </div>

                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-gray-400">Temperature</span>
                      <div className="flex items-center gap-2">
                        <span className="text-lg font-semibold">{selectedAstronautData.vitals.temperature.toFixed(1)}</span>
                        <span className="text-sm text-gray-400">°C</span>
                        <Thermometer className="h-4 w-4 text-orange-400" />
                      </div>
                    </div>
                    <Progress 
                      value={((selectedAstronautData.vitals.temperature - 35) / 4) * 100} 
                      className="h-2"
                    />
                  </div>

                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-gray-400">Respiration Rate</span>
                      <div className="flex items-center gap-2">
                        <span className="text-lg font-semibold">{selectedAstronautData.vitals.respirationRate}</span>
                        <span className="text-sm text-gray-400">breaths/min</span>
                        <Wind className="h-4 w-4 text-cyan-400" />
                      </div>
                    </div>
                    <Progress 
                      value={(selectedAstronautData.vitals.respirationRate / 30) * 100} 
                      className="h-2"
                    />
                  </div>
                </CardContent>
              </Card>

              {/* Secondary Vitals */}
              <Card className="bg-slate-800/50 border-slate-700">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Activity className="h-5 w-5 text-purple-400" />
                    Secondary Metrics
                  </CardTitle>
                  <CardDescription>
                    Additional health and wellness parameters
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-gray-400">Blood Pressure</span>
                      <span className="text-lg font-semibold">
                        {selectedAstronautData.vitals.bloodPressure.systolic}/{selectedAstronautData.vitals.bloodPressure.diastolic}
                      </span>
                    </div>
                    <div className="text-xs text-gray-500">mmHg</div>
                  </div>

                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-gray-400">Stress Level</span>
                      <div className="flex items-center gap-2">
                        <span className="text-lg font-semibold">{selectedAstronautData.vitals.stressLevel.toFixed(0)}</span>
                        <span className="text-sm text-gray-400">%</span>
                      </div>
                    </div>
                    <Progress value={selectedAstronautData.vitals.stressLevel} className="h-2" />
                  </div>

                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-gray-400">Hydration Level</span>
                      <div className="flex items-center gap-2">
                        <span className="text-lg font-semibold">{selectedAstronautData.vitals.hydration.toFixed(0)}</span>
                        <span className="text-sm text-gray-400">%</span>
                      </div>
                    </div>
                    <Progress value={selectedAstronautData.vitals.hydration} className="h-2" />
                  </div>

                  <Separator />

                  <div className="bg-slate-700/50 p-3 rounded-lg">
                    <div className="text-xs text-gray-400 mb-1">Last Updated</div>
                    <div className="text-sm font-mono">
                      {new Date(selectedAstronautData.lastUpdate).toLocaleTimeString()}
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Suit Telemetry Tab */}
          <TabsContent value="suit">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Life Support */}
              <Card className="bg-slate-800/50 border-slate-700">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Wind className="h-5 w-5 text-cyan-400" />
                    Life Support Systems
                  </CardTitle>
                  <CardDescription>
                    EVA suit life support and environmental controls
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-gray-400">Primary Oxygen</span>
                      <div className="flex items-center gap-2">
                        <span className="text-lg font-semibold">{selectedAstronautData.suit.primaryOxygen.toFixed(1)}</span>
                        <span className="text-sm text-gray-400">%</span>
                      </div>
                    </div>
                    <Progress 
                      value={selectedAstronautData.suit.primaryOxygen} 
                      className="h-2"
                    />
                  </div>

                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-gray-400">Secondary Oxygen</span>
                      <div className="flex items-center gap-2">
                        <span className="text-lg font-semibold">{selectedAstronautData.suit.secondaryOxygen.toFixed(1)}</span>
                        <span className="text-sm text-gray-400">%</span>
                      </div>
                    </div>
                    <Progress 
                      value={selectedAstronautData.suit.secondaryOxygen} 
                      className="h-2"
                    />
                  </div>

                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-gray-400">CO₂ Scrubber</span>
                      <div className="flex items-center gap-2">
                        <span className="text-lg font-semibold">{selectedAstronautData.suit.co2Scrubber.toFixed(1)}</span>
                        <span className="text-sm text-gray-400">%</span>
                      </div>
                    </div>
                    <Progress 
                      value={selectedAstronautData.suit.co2Scrubber} 
                      className="h-2"
                    />
                  </div>

                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-gray-400">Cooling System</span>
                      <div className="flex items-center gap-2">
                        <span className="text-lg font-semibold">{selectedAstronautData.suit.coolingSystem.toFixed(1)}</span>
                        <span className="text-sm text-gray-400">%</span>
                      </div>
                    </div>
                    <Progress 
                      value={selectedAstronautData.suit.coolingSystem} 
                      className="h-2"
                    />
                  </div>
                </CardContent>
              </Card>

              {/* Systems Status */}
              <Card className="bg-slate-800/50 border-slate-700">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Zap className="h-5 w-5 text-yellow-400" />
                    Systems Status
                  </CardTitle>
                  <CardDescription>
                    Power, communications, and suit integrity
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-gray-400">Battery Power</span>
                      <div className="flex items-center gap-2">
                        <span className="text-lg font-semibold">{selectedAstronautData.suit.batteryPower.toFixed(1)}</span>
                        <span className="text-sm text-gray-400">%</span>
                        <Battery className="h-4 w-4 text-yellow-400" />
                      </div>
                    </div>
                    <Progress 
                      value={selectedAstronautData.suit.batteryPower} 
                      className="h-2"
                    />
                  </div>

                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-gray-400">Communication Signal</span>
                      <div className="flex items-center gap-2">
                        <span className="text-lg font-semibold">{selectedAstronautData.suit.communicationSignal.toFixed(0)}</span>
                        <span className="text-sm text-gray-400">%</span>
                        <Radio className="h-4 w-4 text-green-400" />
                      </div>
                    </div>
                    <Progress 
                      value={selectedAstronautData.suit.communicationSignal} 
                      className="h-2"
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <div className="text-sm text-gray-400">Internal Pressure</div>
                      <div className="text-lg font-semibold">
                        {selectedAstronautData.suit.internalPressure.toFixed(1)} psi
                      </div>
                    </div>
                    <div className="space-y-2">
                      <div className="text-sm text-gray-400">External Pressure</div>
                      <div className="text-lg font-semibold">
                        {selectedAstronautData.suit.externalPressure.toFixed(1)} psi
                      </div>
                    </div>
                  </div>

                  <Separator />

                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-gray-400">Suit Integrity</span>
                      <Badge 
                        variant={selectedAstronautData.eva.suitIntegrity > 95 ? "default" : 
                                selectedAstronautData.eva.suitIntegrity > 90 ? "secondary" : "destructive"}
                      >
                        {selectedAstronautData.eva.suitIntegrity.toFixed(1)}%
                      </Badge>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* EVA Tracking Tab */}
          <TabsContent value="eva">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* EVA Status */}
              <Card className="bg-slate-800/50 border-slate-700">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <MapPin className="h-5 w-5 text-green-400" />
                    EVA Status
                  </CardTitle>
                  <CardDescription>
                    Current EVA mission information and progress
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-400">EVA Status</span>
                    <Badge 
                      variant={selectedAstronautData.eva.status === 'active' ? "default" : 
                              selectedAstronautData.eva.status === 'preparing' ? "secondary" : 
                              selectedAstronautData.eva.status === 'emergency' ? "destructive" : "outline"}
                    >
                      {selectedAstronautData.eva.status}
                    </Badge>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <div className="text-sm text-gray-400">Duration</div>
                      <div className="text-lg font-semibold">{selectedAstronautData.eva.duration}</div>
                    </div>
                    <div className="space-y-2">
                      <div className="text-sm text-gray-400">Start Time</div>
                      <div className="text-lg font-semibold">{selectedAstronautData.eva.startTime}</div>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <div className="text-sm text-gray-400">Current Task</div>
                    <div className="text-lg font-semibold">{selectedAstronautData.eva.currentTask}</div>
                  </div>

                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-gray-400">Task Progress</span>
                      <span className="text-sm font-medium">
                        {selectedAstronautData.eva.completedTasks}/{selectedAstronautData.eva.totalTasks}
                      </span>
                    </div>
                    <Progress 
                      value={(selectedAstronautData.eva.completedTasks / selectedAstronautData.eva.totalTasks) * 100} 
                      className="h-2"
                    />
                  </div>

                  <div className="space-y-2">
                    <div className="text-sm text-gray-400">Distance Traveled</div>
                    <div className="text-lg font-semibold">{selectedAstronautData.eva.distanceTraveled.toFixed(0)}m</div>
                  </div>
                </CardContent>
              </Card>

              {/* Location Tracking */}
              <Card className="bg-slate-800/50 border-slate-700">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Satellite className="h-5 w-5 text-purple-400" />
                    Location Tracking
                  </CardTitle>
                  <CardDescription>
                    Real-time position and navigation data
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <div className="text-sm text-gray-400">Current Coordinates</div>
                    <div className="grid grid-cols-3 gap-2 text-xs">
                      <div className="bg-slate-700/50 p-2 rounded text-center">
                        <div className="text-gray-500">X</div>
                        <div className="font-mono">{selectedAstronautData.eva.location.x.toFixed(0)}</div>
                      </div>
                      <div className="bg-slate-700/50 p-2 rounded text-center">
                        <div className="text-gray-500">Y</div>
                        <div className="font-mono">{selectedAstronautData.eva.location.y.toFixed(0)}</div>
                      </div>
                      <div className="bg-slate-700/50 p-2 rounded text-center">
                        <div className="text-gray-500">Z</div>
                        <div className="font-mono">{selectedAstronautData.eva.location.z.toFixed(0)}</div>
                      </div>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <div className="text-sm text-gray-400">EVA Timeline</div>
                    <div className="space-y-2">
                      <div className="flex items-center gap-2 text-xs">
                        <div className="w-2 h-2 bg-green-400 rounded-full" />
                        <span>EVA Start - {selectedAstronautData.eva.startTime}</span>
                      </div>
                      <div className="flex items-center gap-2 text-xs">
                        <div className="w-2 h-2 bg-blue-400 rounded-full animate-pulse" />
                        <span>Current - {selectedAstronautData.eva.currentTask}</span>
                      </div>
                      <div className="flex items-center gap-2 text-xs">
                        <div className="w-2 h-2 bg-gray-400 rounded-full" />
                        <span>Estimated End - {selectedAstronautData.eva.duration}</span>
                      </div>
                    </div>
                  </div>

                  <Separator />

                  <div className="bg-slate-700/50 p-3 rounded-lg">
                    <div className="text-xs text-gray-400 mb-2">Navigation Status</div>
                    <div className="flex items-center gap-2">
                      <Satellite className="h-4 w-4 text-green-400" />
                      <span className="text-sm">GPS Signal Strong</span>
                    </div>
                    <div className="flex items-center gap-2 mt-1">
                      <Target className="h-4 w-4 text-blue-400" />
                      <span className="text-sm">On Course to Target</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Alerts Tab */}
          <TabsContent value="alerts">
            <Card className="bg-slate-800/50 border-slate-700">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5 text-orange-400" />
                  System Alerts & Warnings
                </CardTitle>
                <CardDescription>
                  Real-time alerts and recommendations for astronaut safety
                </CardDescription>
              </CardHeader>
              <CardContent>
                <ScrollArea className="h-96">
                  <div className="space-y-3">
                    {/* Critical Alerts */}
                    {selectedAstronautData.status === 'critical' && (
                      <div className="p-3 bg-red-900/20 border border-red-400 rounded-lg">
                        <div className="flex items-start gap-3">
                          <AlertCircle className="h-5 w-5 text-red-400 mt-0.5" />
                          <div>
                            <div className="font-semibold text-red-400">CRITICAL ALERT</div>
                            <div className="text-sm text-gray-300 mt-1">
                              Immediate attention required - Multiple vital signs outside normal parameters
                            </div>
                            <div className="text-xs text-gray-400 mt-2">
                              {new Date().toLocaleTimeString()}
                            </div>
                          </div>
                        </div>
                      </div>
                    )}

                    {/* Warning Alerts */}
                    {selectedAstronautData.status === 'warning' && (
                      <div className="p-3 bg-yellow-900/20 border border-yellow-400 rounded-lg">
                        <div className="flex items-start gap-3">
                          <AlertTriangle className="h-5 w-5 text-yellow-400 mt-0.5" />
                          <div>
                            <div className="font-semibold text-yellow-400">WARNING</div>
                            <div className="text-sm text-gray-300 mt-1">
                              Some parameters require monitoring - Consider adjusting activity level
                            </div>
                            <div className="text-xs text-gray-400 mt-2">
                              {new Date().toLocaleTimeString()}
                            </div>
                          </div>
                        </div>
                      </div>
                    )}

                    {/* System-specific alerts */}
                    {selectedAstronautData.suit.batteryPower < 50 && (
                      <div className="p-3 bg-orange-900/20 border border-orange-400 rounded-lg">
                        <div className="flex items-start gap-3">
                          <Battery className="h-5 w-5 text-orange-400 mt-0.5" />
                          <div>
                            <div className="font-semibold text-orange-400">Low Battery Warning</div>
                            <div className="text-sm text-gray-300 mt-1">
                              Suit battery at {selectedAstronautData.suit.batteryPower.toFixed(1)}% - 
                              Consider returning to habitat or switching to secondary power
                            </div>
                            <div className="text-xs text-gray-400 mt-2">
                              {new Date().toLocaleTimeString()}
                            </div>
                          </div>
                        </div>
                      </div>
                    )}

                    {selectedAstronautData.suit.primaryOxygen < 70 && (
                      <div className="p-3 bg-blue-900/20 border border-blue-400 rounded-lg">
                        <div className="flex items-start gap-3">
                          <Wind className="h-5 w-5 text-blue-400 mt-0.5" />
                          <div>
                            <div className="font-semibold text-blue-400">Oxygen Level Alert</div>
                            <div className="text-sm text-gray-300 mt-1">
                              Primary oxygen at {selectedAstronautData.suit.primaryOxygen.toFixed(1)}% - 
                              Secondary system available
                            </div>
                            <div className="text-xs text-gray-400 mt-2">
                              {new Date().toLocaleTimeString()}
                            </div>
                          </div>
                        </div>
                      </div>
                    )}

                    {selectedAstronautData.vitals.hydration < 75 && (
                      <div className="p-3 bg-cyan-900/20 border border-cyan-400 rounded-lg">
                        <div className="flex items-start gap-3">
                          <Droplets className="h-5 w-5 text-cyan-400 mt-0.5" />
                          <div>
                            <div className="font-semibold text-cyan-400">Hydration Reminder</div>
                            <div className="text-sm text-gray-300 mt-1">
                              Hydration level at {selectedAstronautData.vitals.hydration.toFixed(0)}% - 
                              Recommend water intake soon
                            </div>
                            <div className="text-xs text-gray-400 mt-2">
                              {new Date().toLocaleTimeString()}
                            </div>
                          </div>
                        </div>
                      </div>
                    )}

                    {/* Info messages */}
                    <div className="p-3 bg-green-900/20 border border-green-400 rounded-lg">
                      <div className="flex items-start gap-3">
                        <CheckCircle className="h-5 w-5 text-green-400 mt-0.5" />
                        <div>
                          <div className="font-semibold text-green-400">System Nominal</div>
                          <div className="text-sm text-gray-300 mt-1">
                            All systems operating within normal parameters
                          </div>
                          <div className="text-xs text-gray-400 mt-2">
                            {new Date().toLocaleTimeString()}
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </ScrollArea>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      )}

      {/* Monitoring Control */}
      <Card className="bg-slate-800/50 border-slate-700">
        <CardContent className="pt-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Activity className={`h-4 w-4 ${isMonitoring ? 'text-green-400 animate-pulse' : 'text-gray-400'}`} />
              <span className="text-sm text-gray-400">
                Monitoring {isMonitoring ? 'Active' : 'Paused'}
              </span>
            </div>
            <Button
              onClick={() => setIsMonitoring(!isMonitoring)}
              variant={isMonitoring ? "destructive" : "default"}
              size="sm"
            >
              {isMonitoring ? (
                <>
                  <Pause className="h-4 w-4 mr-2" />
                  Pause Monitoring
                </>
              ) : (
                <>
                  <Play className="h-4 w-4 mr-2" />
                  Resume Monitoring
                </>
              )}
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}